set -euo pipefail
p=$(cd "$(dirname "$0")" && pwd)
source "$p/environment.sh"
test "$CUDA_VISIBLE_DEVICES" = GPU-7bafb1de-da7b-3bf6-e8cd-2369e0c92767
cd "$p/c2-replay"
for t in 0 1; do python -u bench3.py "$t" 128; done
cd "$p/fa-fixed"; python -u fixed_run.py
