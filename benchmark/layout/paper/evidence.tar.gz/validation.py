from pathlib import Path
import re,json,csv,hashlib,subprocess,sys,importlib.metadata as md
p=Path(__file__).resolve().parent;repo=Path('/home/baopeihua/frisk')
def failures(f):
 s=(p/f).read_text()
 return dict(ran=int(re.search(r'Ran (\d+) tests',s)[1]),failures=sorted(re.findall(r'^(?:FAIL|ERROR): [^\n]+',s,re.M)))
before=failures('baseline-affected-units.log');after=failures('backend-units-final.log');initial=failures('backend-units-with-fixtures.log')
assert before['failures']==initial['failures'] and set(after['failures'])<set(initial['failures']) and len(after['failures'])==15
cpp=[int(re.search(r'\[  PASSED  \] (\d+) tests', (p/f).read_text())[1]) for f in ('cpp-layout.log','cpp-selection.log')]
assert cpp==[710,65] and 'Passed: 109 (100.00%)' in (p/'lit.log').read_text()
assert 'ss kernel [(1, 2), (2, 1)]' in (p/'c2.log').read_text() and 'rs kernel [(2, 1)]' in (p/'c2.log').read_text()
def meta(*args):return subprocess.check_output(args,text=True).strip()
prov=dict(source=(p/'source.commit').read_text().strip(),tests=(p/'tests.commit').read_text().strip(),baseline=meta('git','-C',str(repo),'rev-parse','58d16b3'),frisk_opt=(p/'opt.sha256').read_text().split()[0],gpu=meta('nvidia-smi','-i','0','--query-gpu=index,uuid,name,driver_version,memory.total','--format=csv,noheader'),toolkit=meta('nvcc','--version').splitlines()[-2:],packages={k:md.version(k) for k in ('torch','triton','tilelang','numpy')},current_source_checkouts={str(r):meta('git','-C',str(r),'rev-parse','HEAD') for r in [Path('/home/baopeihua/pipeline/triton'),Path('/home/baopeihua/tilelang')]},external_images='Historical peer builds are identified by the maps, receipts and hashes in the replay recipes. Local checkout revisions describe the machine at regression time.')
v=dict(provenance=prov,lit=109,cpp_layout=cpp[0],cpp_selection=cpp[1],geometry_tool=(p/'layout-tool.log').read_text().strip(),c2=json.loads((p/'c2-replay/hash-check.json').read_text()),python_current=after,python_before_cleanup=before,python_resolved=sorted(set(before['failures'])-set(after['failures'])),fa_partial_tail=(p/'fa3-guard.log').read_text().splitlines()[-1],physical={})
for d in (p/'physical').glob('*/results.json'):
 a=json.loads(d.read_text());assert a['bitwise_equal'] and a['static_compiles']==1
 v['physical'][d.parent.name]={k:a[k] for k in ('static','static_compiles','cubin_sha256','physical_contract_sha256','bitwise_equal','static_error')}
assert len(v['physical'])==2
v['retired']=json.loads((p/'retired.json').read_text());v['ablation_profiled_kernels']=len(list(csv.reader((p/'factorial/traffic.csv').open())))-2
v['open_residency_delivery']=json.loads((p/'anchor/opened.json').read_text());assert len(v['open_residency_delivery'])==6
(p/'paper/validation.json').write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
