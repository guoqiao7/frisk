from benchlib import *
from fixed_build import N,ENG
def main(n,ca,sess):
 q,k,v,ref=inputs(n,64,8,ca,119+sess+ca)
 buf=torch.full((ref.numel()+128,),-37.,device='cuda');o=buf[64:-64].view_as(ref)
 imgs=[];gs={};aliases={};errs={}
 for w in (1,4,'prefetch-v'):
  for e in ENG:
   name=f'{w}-{e}';f=ROOT/'fixed'/f'{n}-{ca}-{w}'/e;info=json.loads((f/'receipt.json').read_text());key=info['cubin']
   aliases[name]=key
   im=Raw(f/'kernel.cubin','replay',(8*((n+255)//256),1,1),256,65536);imgs.append(im)
   g,errs[name]=graph(lambda:im.launch(q,k,v,o,None),buf,ref,4)
   gs.setdefault(key,g)
 times=timing(gs,4,78000+n+ca+1000*sess,24)
 (ROOT/'fixed'/f'time-{n}-{ca}-{sess}.json').write_text(json.dumps(dict(aliases=aliases,errors=errs,samples=times)))
 gs.clear();del g
 for im in imgs:im.close()
 print(n,ca,sess,flush=True)
if __name__=='__main__':
 for sess in (0,1):
  cases=[(n,c) for n in N for c in (0,1)];random.Random(902+sess).shuffle(cases)
  for n,ca in cases:main(n,ca,sess)
