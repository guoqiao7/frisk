import ctypes as C, json, math, random, statistics, time
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
P=C.c_void_p
I=C.c_int
U=C.c_uint
lib=C.CDLL('libcuda.so.1')
def api(name,types,*args):
 f=getattr(lib,name);f.argtypes=types;res=f(*args)
 if res:raise RuntimeError((name,res))
class Raw:
 def __init__(self,path,name,grid,threads,shared=0):
  self.buf=path.read_bytes();self.mod=P();self.fn=P()
  api('cuModuleLoadData',[C.POINTER(P),P],C.byref(self.mod),C.cast(C.c_char_p(self.buf),P))
  api('cuModuleGetFunction',[C.POINTER(P),P,C.c_char_p],C.byref(self.fn),self.mod,name.encode())
  if shared:api('cuFuncSetAttribute',[P,I,I],self.fn,8,shared)
  self.grid=grid;self.threads=threads;self.shared=shared
 def launch(self,*args):
  dat=[P(x.data_ptr() if x is not None else 0) for x in args]
  par=(P*len(dat))(*(C.cast(C.byref(x),P) for x in dat))
  api('cuLaunchKernel',[P]+[U]*7+[P,C.POINTER(P),P],self.fn,*self.grid,self.threads,1,1,self.shared,torch.cuda.current_stream().cuda_stream,par,None)
 def close(self):api('cuModuleUnload',[P],self.mod)
def inputs(n,d,h,ca,seed):
 torch.backends.cuda.matmul.allow_tf32=False
 gen=torch.Generator(device='cuda').manual_seed(seed)
 q,k,v=[torch.randn((1,h,n,d),dtype=torch.float16,device='cuda',generator=gen)*.65 for _ in range(3)]
 # Include a position-dependent marker to distinguish causal from full rows.
 v[...,0]=(torch.arange(n,device='cuda')/(n-1)).half()
 ref=torch.empty_like(q,dtype=torch.float32)
 kt=k.float().transpose(-1,-2);vf=v.float()
 for b in range(0,n,128):
  scores=(q[:,:,b:b+128].float()@kt)/math.sqrt(d)
  if ca:scores.masked_fill_(torch.arange(n,device='cuda')[None,:]>torch.arange(b,min(n,b+128),device='cuda')[:,None],-math.inf)
  ref[:,:,b:b+128]=scores.softmax(-1)@vf
 return q,k,v,ref
def graph(run,buf,ref,reps):
 out=buf[64:-64].view_as(ref)
 out.fill_(float('nan'));run();torch.cuda.synchronize()
 err=(out.float()-ref).abs()
 assert torch.isfinite(out).all() and err.max()<.003 and (buf[:64]==-37).all() and (buf[-64:]==-37).all(),err.max().item()
 maximum=err.max().item()
 g=torch.cuda.CUDAGraph()
 with torch.cuda.graph(g):
  for _ in range(reps):run()
 out.fill_(float('nan'));g.replay();torch.cuda.synchronize()
 assert (out.float()-ref).abs().max()<.003 and (buf[:64]==-37).all() and (buf[-64:]==-37).all()
 return g,maximum
def timing(graphs,reps,seed,blocks=24):
 rng=random.Random(seed);names=list(graphs);out=[]
 end=time.monotonic()+.12
 while time.monotonic()<end:
  for g in graphs.values():g.replay()
  torch.cuda.synchronize()
 for block in range(blocks):
  if block%len(names)==0:rng.shuffle(names)
  order=names[block%len(names):]+names[:block%len(names)]
  events={}
  for nm in order:
   a=torch.cuda.Event(enable_timing=True);z=torch.cuda.Event(enable_timing=True)
   a.record();graphs[nm].replay();z.record();events[nm]=(a,z)
  torch.cuda.synchronize();out.append({k:a.elapsed_time(z)*1000/reps for k,(a,z) in events.items()})
 return out
