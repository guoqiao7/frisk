from pathlib import Path
import concurrent.futures, json, subprocess, hashlib, re, time
D=Path(__file__).resolve().parent
OLD=Path('/data0/baopeihua/frisk-layout-sweep-qm6ScO/fa')
N=[127,256,511,640,1025,1536]
ENG=['triton','tilelang','frisk']
def sha(data):return hashlib.sha256(data).hexdigest()
def build(job):
 n,ca,e,w=job
 c=('causal' if ca else 'fa')+str(n)
 cert=json.loads((OLD/'status'/('compiled-'+c+'.json')).read_text())
 orig=OLD/'images'/(c+'-'+e)
 assert sha((orig/'kernel.cubin').read_bytes())==cert['db'][c+'-'+e]['cubin']
 s=(orig/'kernel.cu').read_text()
 if w==4:
  fence='asm volatile("wgmma.fence.sync.aligned;" ::: "memory");'
  retire=r'asm volatile("wgmma.commit_group.sync.aligned;\n\twgmma.wait_group.sync.aligned 0;" ::: "memory");'
  assert s.count(fence)==s.count(retire)==2
  s=s.replace(fence,'').replace(retire,'')
  # All four outputs of a K16 slice have independent accumulators and share
  # the same input lifetime. Drain before the next shared buffer overwrite.
  for start in ['atom(scores','rs(acc']:
   pos=s.index(start);lo=s.rindex('    #pragma unroll\n    for(int r=0;r<REP;r++)',0,pos)
   end=s.index('\n    }',pos)+6
   s=s[:lo]+'    '+fence+'\n'+s[lo:end]+'\n    '+retire+s[end:]
  assert s.count(fence)==s.count(retire)==2
 if w=='prefetch-v':
  marker='  float scores[REP][NC][16]={};'
  assert s.count(marker)==1
  load='''  half early_v[4];
  #pragma unroll
  for(int it=0;it<4;it++){
    int z=tid+it*256, i=z/64, j=z%64;
    unsigned short raw=0;
    if(kb+i<N) asm volatile("ld.global.u16 %0,[%1];" : "=h"(raw) : "l"(V+((kvhead*N+kb+i)*64)+j) : "memory");
    early_v[it]=__ushort_as_half(raw);
  }
'''
  old='*(half*)(sb+off)=kb+kk+i<N?V[((kvhead*N+kb+kk+i)*64)+j]:__float2half(0);'
  assert s.count(old)==1
  s=s.replace(marker,load+marker).replace(old,old.replace('=kb+kk+i<N?', '=kk==0?early_v[it]:kb+kk+i<N?'))
 root=D/'fixed'/f'{n}-{ca}-{w}'/e;root.mkdir(parents=True,exist_ok=True)
 (root/'kernel.cu').write_text(s)
 t=time.perf_counter()
 with (root/'build.log').open('w') as log:subprocess.run(['/usr/local/cuda/bin/nvcc','--cubin','-arch=sm_90a','-O3','-Xptxas=-v','kernel.cu','-o','kernel.cubin'],cwd=root,check=True,stderr=log)
 ss=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','-sass','kernel.cubin'],cwd=root,text=True);(root/'kernel.sass').write_text(ss)
 info=dict(engine=e,mask=ca,n=n,wait=w,maps=cert['arms'][e],original=cert['db'][c+'-'+e],source=sha(s.encode()),cubin=sha((root/'kernel.cubin').read_bytes()),build_s=time.perf_counter()-t,dep=ss.count('WARPGROUP.DEPBAR'),mma=ss.count('HGMMA.'),arrive=ss.count('WARPGROUP.ARRIVE'))
 if w==1:assert info['cubin']==info['original']['cubin']
 (root/'receipt.json').write_text(json.dumps(info,indent=2))
 return info
if __name__=='__main__':
 jobs=[(n,c,e,w) for n in N for c in (0,1) for e in ENG for w in (1,4,'prefetch-v')]
 with concurrent.futures.ThreadPoolExecutor(4) as ex: rows=list(ex.map(build,jobs))
 for a in rows:
  for b in rows:
   if (a['mask'],a['n'],a['wait'],a['maps'])==(b['mask'],b['n'],b['wait'],b['maps']):assert a['cubin']==b['cubin']
   if (a['mask'],a['n'],a['engine'])==(b['mask'],b['n'],b['engine']) and a['wait']==1 and b['wait']==4:assert a['dep']>b['dep']
 print('passed',len(rows))
