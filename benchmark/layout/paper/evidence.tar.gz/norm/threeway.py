from pathlib import Path
import hashlib
import run as suite
from timing import paired
from suite_run import dump,torch,r,tag,ref
D=suite.D
torch.manual_seed(71823)
for m,n,o in [suite.spec['target'],*suite.spec['regressions']]:
    loc,previous,base,policies=suite.info([m,n,o])
    policies=suite.read(loc/'manifest.json')['policies']
    for elements in (2**20,2**23):
        g=elements//(m*n)
        x=torch.randn(g,m,n,device='cuda'); y=torch.empty_like(x)
        expected=ref(x,o)
        def prepare(ir):
            try: policy=r.policy(ir,m,n,o)
            except AssertionError as exc: raise ValueError('unsupported placement') from exc
            return r.launch(x,y,m,n,o,policy)
        picked=suite.cn.compile_normalization_layout(loc/'input.mlir',suite.os.environ['FRISK_OPT'],D/'public',m,n,prepare,grid_ctas=g,reuse=suite.inference(m,n,g,1,1,([x],[y])))
        receipt=picked.receipt
        gs={}; ids={}
        for arm in [*receipt['records'],'triton','tilelang']:
            pol=policies[arm]
            y.fill_(float('nan'))
            im=r.launch(x,y,m,n,o,pol)
            torch.testing.assert_close(y,expected,rtol=2e-5,atol=1e-5)
            h=hashlib.sha256(im.asm['cubin']).hexdigest()
            if arm in receipt['records']: assert h==receipt['records'][arm]['cubin']
            ids[arm]=h
            if h in gs: continue
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                for _ in range(6): r.launch(x,y,m,n,o,pol)
            gs[h]=graph
        z=paired(gs,dict(F=list(dict.fromkeys(ids[a] for a in receipt['records'])),T=[ids['triton']],L=[ids['tilelang']]),ids[receipt['selected']],tag(m,n,o)+str(g))
        z.update(kind='layout',op=['Softmax','RMSNorm','LayerNorm'][o],shape=f'{m}x{n}',grid=g,mode=receipt['selected'],arms=ids)
        dump(D.parent/'sweep'/'data'/f'norm-{tag(m,n,o)}-g{g}.json',z)
        print(m,n,o,g,receipt['selected'],flush=True)
