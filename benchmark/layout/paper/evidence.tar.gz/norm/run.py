from pathlib import Path
import sys,os,hashlib,random,math,json,itertools,statistics
import numpy as np
from suite_run import tag,read,dump,load_version,ref,r,torch
D=Path(__file__).resolve().parent;P=Path(os.environ['PRIOR']);E=Path(os.environ['E']);cn=load_version(E)
from normalization_reuse import NormalizationReuse
from normalization_schedule import rank_grid
assert Path(sys.modules['normalization_reuse'].__file__).resolve().parent==E
spec=read(D/'design.json');sm=torch.cuda.get_device_properties(0).multi_processor_count
l2=torch.cuda.get_device_properties(0).L2_cache_size
def group(c):
 if c==spec['target']:return 'target'
 return 'control' if c in spec['regressions'] else 'blind'
def cases():return [spec['target'],*spec['regressions'],*spec['blind']]
def info(c):
 m,n,o=c;key=tag(*c);loc=(D/'cases' if group(c)=='blind' else P/'norm')/key
 if group(c)=='blind':
  j=read(loc/'case.json');return loc,j['records'],j['baseline'],j['policies']
 d=read(loc/'decisions.json');rs=read(Path(d['record'])/'selection.json')['records'];pol=read(loc/'manifest.json')['policies']
 return loc,rs,d['old'],{k:pol[k] for k in rs}
def configs(c):
 if group(c)=='control':
  return [(v//(c[0]*c[1]),1,1) for v in (1048576,8388608)]
 return [(g,nx,ny) for g in spec['grids'] for nx,ny in spec['versions']]
def inference(m,n,g,nx,ny,actual=None):
 count=math.lcm(nx,ny);sz=m*n*g*4
 if actual is None:trace=[((i%nx*sz,sz),((nx+i%ny)*sz,sz)) for i in range(count)]
 else:
  x,y=actual;trace=[((x[i%nx].data_ptr(),sz),(y[i%ny].data_ptr(),sz)) for i in range(count)]
 return NormalizationReuse.from_launches(trace,0,cyclic=True)
def decisions():
 out={}
 for c in cases():
  key=tag(*c);loc,rs,base,pol=info(c);out[key]={}
  for g,nx,ny in configs(c):
   reuse=inference(*c[:2],g,nx,ny)
   previous=rank_grid(rs,base,g,sm)[0];win,rec=rank_grid(rs,base,g,sm,reuse=reuse,l2_bytes=l2)
   out[key][f'{g}-{nx}-{ny}']=dict(selected=win,before=previous,details=rec,cubin=rs[win]['cubin'])
 dump(D/'decisions.json',out)
def public():
 c=spec['target'];key=tag(*c);m,n,o=c;loc,rs,base,pol=info(c);picks=read(D/'decisions.json')[key]
 rows=[]
 for g,nx,ny in configs(c):
  x=torch.randn(nx,g,m,n,device='cuda');y=torch.empty(ny,g,m,n,device='cuda');truth=ref(x[0],o)
  reuse=inference(m,n,g,nx,ny,(x,y));assert reuse==inference(m,n,g,nx,ny)
  def prepare(ir):
   try:policy=r.policy(ir,m,n,o)
   except AssertionError as exc:raise ValueError('unsupported placement') from exc
   return r.launch(x[0],y[0],m,n,o,policy)
  ret=cn.compile_normalization_layout(loc/'input.mlir',os.environ['FRISK_OPT'],D/'public',m,n,prepare,grid_ctas=g,reuse=reuse)
  j=ret.receipt;pick=picks[f'{g}-{nx}-{ny}']
  assert j['selected']==pick['selected'] and j['grid_ranking']==pick['details']
  assert {k:v['cubin'] for k,v in j['records'].items()}=={k:v['cubin'] for k,v in rs.items()}
  ld,ws,st,early=r.policy(ret.materialized,m,n,o);args=[x[0],y[0],m,n,o,1,False,r.vec(m,n,ld),*[r.vec(m,n,w) for w in ws+[ws[-1]]*(7-len(ws))],r.vec(m,n,st),early]
  y[0].fill_(float('nan'));ret.image[(g,1,1)](*args);torch.testing.assert_close(y[0],truth,rtol=2e-5,atol=1e-5)
  rows.append(dict(grid=g,nx=nx,ny=ny,selected=j['selected'],receipt=j['directory']))
 dump(D/'public-check.json',rows)
def measure(c,config,rep,picks):
 g,nx,ny=config;m,n,o=c;key=tag(*c);loc,rs,base,pol=info(c)
 x=torch.randn(nx,g,m,n,device='cuda');y=torch.empty(ny,g,m,n,device='cuda')
 contract=inference(m,n,g,nx,ny,(x,y))
 z=picks[key][f'{g}-{nx}-{ny}'];winner,det=rank_grid(rs,base,g,sm,reuse=contract,l2_bytes=l2);assert winner==z['selected'] and det==z['details']
 truth=ref(x[0],o);graphs={};aliases={}
 for a,rec in rs.items():
  h=rec['cubin'];aliases[a]=h
  if h in graphs:continue
  y[0].fill_(float('nan'));im=r.launch(x[0],y[0],m,n,o,pol[a]);torch.testing.assert_close(y[0],truth,rtol=2e-5,atol=1e-5)
  assert hashlib.sha256(im.asm['cubin']).hexdigest()==h
  cg=torch.cuda.CUDAGraph()
  with torch.cuda.graph(cg):
   for k in range(32):r.launch(x[k%nx],y[k%ny],m,n,o,pol[a])
  graphs[h]=cg
 rng=random.Random(1839+rep*23617+g+nx+3*ny+m*13+n*19+o)
 ev=[torch.cuda.Event(enable_timing=True) for _ in range(2)]
 samples=[]
 for b in range(30):
  if b%2==0:
   order=list(graphs);rng.shuffle(order)
  else:order=order[::-1]
  times={}
  for h in order:
   st,en=ev;st.record();graphs[h].replay();en.record();en.synchronize();times[h]=1000*st.elapsed_time(en)/32
  if b>=6:samples.append(times)
 out=D/'raw'/f'{key}-g{g}-x{nx}-y{ny}-{rep}.json'
 dump(out,dict(case=c,grid=g,nx=nx,ny=ny,rep=rep,aliases=aliases,selected=winner,before=z['before'],samples=samples))
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='decide':decisions()
 elif mode=='public':public()
 else:
  picks=read(D/'decisions.json')
  for rep in (0,1):
   todo=[(c,v) for c in cases() for v in configs(c)];random.Random(42641+rep).shuffle(todo);torch.manual_seed(8232+rep)
   for c,v in todo:measure(c,v,rep,picks)
   print('timed',rep,len(todo),flush=True)
