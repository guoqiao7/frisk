from pathlib import Path
import numpy as np,re,json,sys,hashlib
D=Path(__file__).resolve().parent
OLD=Path('/data0/baopeihua/frisk-anchor-delivery-c2-20261118-OOAfo6')
if (D/'dependencies'/'layout_map.py').exists():OLD=D/'dependencies'
sys.path.insert(0,str(OLD))
from layout_map import holders as rawholders
def holders(s):
    m=re.search(r'matrix = dense<([^>]+)> : tensor<(\d+)x(\d+)xi1>',s)
    if m and m[1].startswith('['):
        bits=[v=='true' for v in re.findall(r'true|false',m[1])]
        assert len(bits)==int(m[2])*int(m[3])
        vv=sum(int(v)<<i for i,v in enumerate(bits))
        s=s[:m.start(1)]+'"0x'+vv.to_bytes((len(bits)+7)//8,'little').hex()+'"'+s[m.end(1):]
    return rawholders(s)
def rd(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True))
def sha(b):return hashlib.sha256(b).hexdigest()
def tile_val(spec):
    sh=spec['shape'];rep=int(re.search(r'replicate: (\d+)',spec['repr'])[1]);ii=np.indices((*sh,rep))
    env={k:v for k,v in zip(['_i','_j'][:len(sh)]+['_rep'],ii)};env['__builtins__']={}
    t=np.broadcast_to(eval(spec['thread'],env),ii.shape[1:]);r=np.broadcast_to(eval(spec['idx'][0],env),t.shape)
    keys=t*spec['out'][0]+r;assert np.unique(keys).size==keys.size and keys.max()+1==keys.size
    vals=np.broadcast_to(np.arange(np.prod(sh)).reshape(*sh,1),t.shape)
    out=np.empty(keys.size,dtype='<i4');out[keys]=vals
    return out.reshape(256,-1)
def fri(s):
    top,coords=holders(s)
    return np.array([(x[0]*512+x[1]) if len(x)==2 else x[0] for x in coords],dtype='<i4').reshape(256,-1)
def run():
    db={};catalog=D/'arrays';catalog.mkdir(exist_ok=True)
    def keep(v):
        b=v.astype('<i4').tobytes();h=sha(b);p=catalog/(h+'.bin')
        if not p.exists():p.write_bytes(b)
        return h
    for engine in ('frisk','tile','triton'):
      for mode in ('ss','rs'):
       for op in ('store','row','col'):
        for pin in ('12','21','open'):
            prefix=f'trirs-{op}' if engine=='triton' and mode=='rs' else f'triton-{op}' if engine=='triton' else f'{engine}-{mode}-{op}'
            path=D/f'{prefix}-{pin}';rs=mode=='rs'
            if engine=='frisk' and pin=='open':
                opt=rd((D/f'frisk-{mode}-local-open')/'result.json')['oracle']['optimal_geometries']
                raw=rd(path/'result.json')['selected_geometries'][0]
                if raw not in opt:
                    assert len(opt)==1;path=D/f'frisk-{mode}-{op}-{opt[0].replace(",","")}'
            maps={}
            if engine=='tile':
                data=rd(path/'layout.json');maps['acc']=tile_val(data['acc'])
                if rs:maps['a']=tile_val(data['aa'])
                if op!='store':maps['red']=tile_val(data['red'])
                maps['out']=maps.get('red',maps['acc'])
                # Native final global store predicate picks the first owning thread.
                cu=(path/'kernel.cu').read_text()
                if op!='store':
                    pred=re.findall(r'^\s*if \((.*)\) \{',cu,re.M)[-1].replace('((int)threadIdx.x)','t')
                    active=[t for t in range(256) if eval(pred,{'t':t,'__builtins__':{}})]
                    vals=maps['out'];first=np.full(vals.max()+1,256)
                    np.minimum.at(first,vals,np.broadcast_to(np.arange(256)[:,None],vals.shape))
                    assert set(active)==set(first.tolist()) and np.all(first[vals[active]]==np.array(active)[:,None])
            elif engine=='triton':
                m=rd(path/'maps.json')
                for role,k in [('acc','acc'),('red','reduced'),('out','store'),('a','lhs')]:
                    if k in m:maps[role]=np.fromfile(D/'probes'/(m[k]+'.bin'),dtype='<i4').reshape(256,-1)
            else:
                ir=(path/'output.mlir').read_text().splitlines()
                line=next(z for z in ir if ' = frisk.mma ' in z)
                maps['acc']=fri(line.split('#frisk.distributed<')[-1])
                if rs:
                    lhs=line.rsplit(' : tensor<128x16xf16, ',1)[-1].split('#frisk.distributed<')[1]
                    top,coords=holders(lhs)
                    maps['a']=np.array([16*i+j for i,j in coords],dtype='<i4').reshape(256,-1)
                line=next(z for z in ir if 'frisk.tile_store ' in z);maps['out']=fri(line.split('#frisk.distributed<')[-1])
                if op!='store':
                    line=next(z for z in ir if ' = frisk.reduce_tensor ' in z);maps['red']=fri(line.split('#frisk.distributed<')[-1])
            grid='12' if maps['acc'][128,0]==256 else '21'
            if pin!='open':assert pin==grid,(engine,mode,op,pin,grid)
            item={k:keep(v) for k,v in maps.items()}
            key=f'{engine}-{mode}-{op}-{pin}';db[key]=dict(grid=grid,maps=item,source=path.name)
    save(D/'plans.json',db)
    for eng in ('frisk','tile','triton'):
        for mode in ('ss','rs'):
            for op in ('store','row','col'):
                x=db[f'{eng}-{mode}-{op}-open'];print(eng,mode,op,x['grid'],{k:v[:5] for k,v in x['maps'].items()})
if __name__=='__main__':run()
