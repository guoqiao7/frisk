from maps import D,rd,save,sha
import os,sys,random,ctypes as ct
import numpy as np
from contextlib import ExitStack
from pathlib import Path
sys.path.insert(0,'/data0/baopeihua/baopeihua-frisk-k-stage-reuse-20261109/checkout/benchmark/layout/execution')
if (D/'dependencies'/'qualify_gemm_standalone.py').exists():sys.path.insert(0,str(D/'dependencies'))
import qualify_gemm_standalone as cu
UUID=os.environ['CUDA_VISIBLE_DEVICES']
os.environ['CUDA_VISIBLE_DEVICES']=UUID
class Image:
 def __init__(self,d,stack,blob,batch):
    self.d=d;self.batch=batch
    m=d.value('cuModuleLoadData',cu.P,ct.c_char_p(blob));stack.callback(d.call,'cuModuleUnload',m)
    self.fn=d.value('cuModuleGetFunction',cu.P,m,b'replay');d.call('cuFuncSetAttribute',self.fn,8,65536)
    self.attrs={k:d.value('cuFuncGetAttribute',cu.I,n,self.fn) for k,n in [('regs',4),('local',3),('static_shared',1)]}
 def launch(self,params):self.d.call('cuLaunchKernel',self.fn,self.batch,1,1,256,1,1,65536,self.d.stream,params,None)
def pack(A,B):
    m,k=np.indices((128,16));ao=(m%8*16+m//8*128+k%8*2+k//8*2048)//2
    k,n=np.indices((16,512));x=n%16*2+n//16*256+k%8*32+k//8*8192;bo=(x^(((x>>7)&1)<<4))//2
    assert np.unique(ao).size==2048 and np.unique(bo).size==8192
    pa=np.empty((len(A),2048),dtype='f2');pb=np.empty((len(A),8192),dtype='f2');pa[:,ao]=A;pb[:,bo]=B
    return pa.tobytes(),pb.tobytes()
def fixtures(b,seed):
    rng=np.random.default_rng(seed)
    for name in ['integer','sparse','random']:
        if name=='integer':a,c=(rng.integers(-4,5,sh).astype('f2') for sh in [(b,128,16),(b,16,512)])
        elif name=='sparse':
            a,c=(np.where(rng.random(sh)<.12,rng.integers(-6,7,sh)/8,0).astype('f2') for sh in [(b,128,16),(b,16,512)])
        else:a,c=(rng.uniform(-1,1,sh).astype('f2') for sh in [(b,128,16),(b,16,512)])
        ref=a.astype('f8')@c.astype('f8');yield name,pack(a,c),ref
def test(mode,op,b,trial,d):
    names=[f'{eng}-{mode}-{op}-{g}' for eng in ('triton','tile','frisk') for g in ('open','12','21')]
    entries=rd(D/'images.json');result=dict(state=cu.gpu_state(UUID),resources={},checks={},blocks=[],b=b)
    n={'store':65536,'row':128,'col':512}[op]*b;guard=256
    with ExitStack() as st:
        ims={k:Image(d,st,(D/'images'/k/'kernel.cubin').read_bytes(),b) for k in names}
        result['resources']={k:i.attrs for k,i in ims.items()}
        vals=[d.allocate(st,x+2*guard) for x in [b*4096,b*16384,n*4]]
        args=[cu.D(v+guard) for v in vals];params=(cu.P*3)(*(ct.cast(ct.byref(x),cu.P) for x in args))
        g=b'\xa7'*guard;blank=g+b'\xff'*(n*4)+g
        for name,inputs,ref in fixtures(b,19+trial):
            for ptr,data in zip(vals[:2],inputs):d.copy_to(ptr,g+data+g)
            ref=ref if op=='store' else ref.sum(axis=2 if op=='row' else 1)
            seen=set();ref=ref.ravel()
            for key,img in ims.items():
                d.copy_to(vals[2],blank);d.synchronize_uploads();img.launch(params);d.synchronize()
                buf=d.copy_from(vals[2],len(blank));assert buf[:guard]==g and buf[-guard:]==g
                raw=buf[guard:-guard];got=np.frombuffer(raw,'<f4')
                assert np.isfinite(got).all()
                err=float(np.max(np.abs(ref-got)));bound=0 if name!='random' else {'store':2e-5,'row':1.5e-3,'col':5e-4}[op]
                if err>bound:raise ValueError((key,name,b,err,bound,np.argmax(abs(ref-got)),got[:4],ref[:4]))
                h=sha(raw);seen.add(h);result['checks'][name+'-'+key]=dict(err=err,hash=h)
            assert len(seen)==1,(mode,op,name,seen)
            for ptr,data in zip(vals[:2],inputs):assert d.copy_from(ptr,len(data)+2*guard)==g+data+g
        # Equal source programs were compiled individually. Load one graph per unique binary
        # so identical images receive one measured time, not a spurious ranking.
        byhash={}
        for k in names:byhash.setdefault(entries[k]['cubin'],k)
        graphs={h:st.enter_context(cu.capture(d,ims[k],params,12)) for h,k in byhash.items()}
        start,stop=[d.value('cuEventCreate',cu.P,0) for _ in range(2)]
        for e in (start,stop):st.callback(d.call,'cuEventDestroy_v2',e)
        for j in range(12):
            for graph in graphs.values():d.call('cuGraphLaunch',graph,d.stream)
        d.synchronize()
        keys=list(graphs);randomizer=random.Random(91+trial+b)
        for j in range(32):
            randomizer.shuffle(keys);times={}
            for h in keys:
                d.call('cuEventRecord',start,d.stream);d.call('cuGraphLaunch',graphs[h],d.stream);d.call('cuEventRecord',stop,d.stream);d.call('cuEventSynchronize',stop)
                t=ct.c_float();d.call('cuEventElapsedTime',ct.byref(t),start,stop);times[h]=t.value*1000/12
            result['blocks'].append(dict(order=list(keys),us=times))
        result['state_after']=cu.gpu_state(UUID);save(D/f'times-{mode}-{op}-{b}-{trial}.json',result)
if __name__=='__main__':
    trial=int(sys.argv[1]);b=int(sys.argv[2])
    with ExitStack() as st:
        cu.gpu_state(UUID);d=cu.Driver(UUID,st);jobs=[(m,o) for m in ('ss','rs') for o in ('store','row','col')]
        random.Random(trial).shuffle(jobs)
        for mode,op in jobs:
            if not (D/f'times-{mode}-{op}-{b}-{trial}.json').exists():test(mode,op,b,trial,d)
            print(trial,b,mode,op,flush=True)
