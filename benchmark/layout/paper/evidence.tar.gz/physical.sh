set -euo pipefail
p=$(cd "$(dirname "$0")" && pwd)
source "$p/environment.sh"
export OPT="$FRISK_OPT"
cd /home/baopeihua/frisk/benchmark/layout/execution
for k in d64-causal gqa; do
 export AROOT="$p/physical/$k"; mkdir -p "$AROOT"
 if test "$k" = gqa; then set -- 920 15 1 64 0 32; else set -- 116 54 54 64 1 32; fi
 python -u "$p/verify-physical.py" selected "$@" > "$AROOT/run.log" 2>&1
done
