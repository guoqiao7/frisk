import unittest,os,sys
from pathlib import Path
p=Path(__file__).parent; repo=Path('/home/baopeihua/frisk')
ex=repo/'benchmark/layout/execution'; sys.path.insert(0,str(ex))
sys.argv=[sys.argv[0],os.environ['FRISK_OPT']]
import test_export,test_hybrid_demand,test_demand_backend,test_demand_observer,test_backend
a=repo/'guoqiao/optimize_plan'
test_backend.INPUT=test_demand_observer.EAGER=str(p/'eager.json')
test_demand_backend.PACKET=test_demand_observer.PACKET=str(a/'current_gpu_closure_artifacts/development/natural-preflight/diamond-32x32-calibrated/execution-compact.json')
test_hybrid_demand.PACKET=str(a/'model_selection_quality_artifacts/run-model-selection-quality-20261102T095146Z/cases/natural-holdout-mixed-16x64-calibrated-LI/execution.json')
test_demand_observer.PREIMAGE=str(a/'demand_cost_search_repair_artifacts/development/backend.py.query-observer.preimage')
suite=unittest.defaultTestLoader.discover(str(ex))
r=unittest.TextTestRunner().run(suite)
sys.exit(not r.wasSuccessful())
