set -euo pipefail
p=$(cd "$(dirname "$0")" && pwd)
source "$p/environment.sh"
cd "$p/factorial"; mkdir -p "$p/ncu-tmp"
TMPDIR="$p/ncu-tmp" ncu --clock-control none --cache-control none --metrics l1tex__t_sectors_pipe_lsu_mem_global_op_ld.sum,l1tex__t_sectors_pipe_lsu_mem_global_op_st.sum,l1tex__t_sectors_pipe_lsu_mem_local_op_ld.sum,l1tex__t_sectors_pipe_lsu_mem_local_op_st.sum,smsp__sass_inst_executed_op_shared_ld.sum,smsp__sass_inst_executed_op_shared_st.sum -o "$p/factorial/traffic" python -u bench.py ncu matrix_m256n512k256 fan_m256n512k256 row_m256n512k256
ncu -i "$p/factorial/traffic.ncu-rep" --page raw --csv > "$p/factorial/traffic.csv"
