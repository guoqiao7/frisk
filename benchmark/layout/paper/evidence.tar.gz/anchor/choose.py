from study import *
def choose(case):
 g,m,n,k=case
 d=root/'images'/tag(case);ir=(d/'input.mlir').read_text();rec=json.loads((d/'record.json').read_text())
 variants={};compiled=set()
 for grid in cfg['grids']:
  o=DenseGemm.from_open_layout(ir,k,resident_atoms=1,delivery='dd',grid_ctas=grid,sm_count=114)
  (d/f'after-{grid}.mlir').write_text(o.layout_ir)
  assert eligible(o.layout_ir)==rec['domain']
  winner=read_choice(o.layout_ir);plan=read_layouts(o.layout_ir)
  assert sig(plan)==rec['arms'][winner]['origins']
  if winner not in compiled:
   im,i=compile_dense_gemm(o)
   assert hashlib.sha256(im.asm['cubin']).hexdigest()==rec['arms'][winner]['sha256']
   compiled.add(winner)
  variants[grid]=dict(after=winner,score=score(o.layout_ir))
 rec['grids']=variants
 (d/'choices.json').write_text(json.dumps(rec,indent=2));print(tag(case),rec['before'],variants,flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(4) as pool:list(pool.map(choose,specs))

