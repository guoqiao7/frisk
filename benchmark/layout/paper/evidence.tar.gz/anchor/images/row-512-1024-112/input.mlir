module attributes {frisk.target = "sm_90a"} {
  func.func @selection(%a: memref<512x112xf16, 1>, %b: memref<112x1024xf16, 1>) {
    %alloc = memref.alloc() {alignment = 1024 : i64} : memref<512x16xf16, 3>
    %0 = frisk.layout_view %alloc : memref<512x16xf16, 3> -> memref<512x16xf16, 3>
    %alloc_0 = memref.alloc() {alignment = 1024 : i64} : memref<16x1024xf16, 3>
    %1 = frisk.layout_view %alloc_0 : memref<16x1024xf16, 3> -> memref<16x1024xf16, 3>
    %cst = arith.constant dense<0.000000e+00> : tensor<512x1024xf32>
    %lo = arith.constant 0 : index
    %hi = arith.constant 112 : index
    %step = arith.constant 16 : index
    %2 = scf.for %iv = %lo to %hi step %step iter_args(%acc = %cst) -> (tensor<512x1024xf32>) {
      %at = memref.subview %a[0,%iv][512,16][1,1] : memref<512x112xf16, 1> to memref<512x16xf16, strided<[112,1], offset: ?>, 1>
      %bt = memref.subview %b[%iv,0][16,1024][1,1] : memref<112x1024xf16, 1> to memref<16x1024xf16, strided<[1024,1], offset: ?>, 1>
      memref.copy %at, %alloc : memref<512x16xf16, strided<[112,1], offset: ?>, 1> to memref<512x16xf16, 3>
      memref.copy %bt, %alloc_0 : memref<16x1024xf16, strided<[1024,1], offset: ?>, 1> to memref<16x1024xf16, 3>
    %next = frisk.mma %0, %1, %acc {frisk.execution_threads = 256 : i64, k = 16 : i64, m = 512 : i64, n = 1024 : i64, policy = #frisk<gemm_warp_policy Auto>} : memref<512x16xf16, 3>, memref<16x1024xf16, 3>, tensor<512x1024xf32> -> tensor<512x1024xf32>
      scf.yield %next : tensor<512x1024xf32>
    }
    %alloc_1 = memref.alloc() {alignment = 128 : i64} : memref<512x1024xf32, 1>
    %3 = frisk.layout_view %alloc_1 {layout = #frisk.storage<map = #frisk.affine_layout<inputs = ["dim0", "dim1"], input_extents = [512, 1024], outputs = ["byte_offset", "bit_offset"], output_extents = [2097152, 8], map = affine_map<(d0, d1) -> (d0 * 4096 + d1 * 4, 0)>>, memory_space = #frisk<memory_space Global>, alignment = 128, vector_granularity = 1>} : memref<512x1024xf32, 1> -> memref<512x1024xf32, 1>
    frisk.tile_store %2, %3 : tensor<512x1024xf32>, memref<512x1024xf32, 1>
    %rs = frisk.reduce_tensor %2 {dim = 1 : i64, frisk.execution_threads = 256 : i64, kind = "sum"} : tensor<512x1024xf32> -> tensor<512xf32>
    %redout = memref.alloc() {alignment = 128 : i64} : memref<512xf32, 1>
    %dst = frisk.layout_view %redout {layout = #frisk.storage<map = #frisk.affine_layout<inputs = ["dim0"], input_extents = [512], outputs = ["byte_offset", "bit_offset"], output_extents = [2048, 8], map = affine_map<(d0) -> (d0 * 4, 0)>>, memory_space = #frisk<memory_space Global>, alignment = 128, vector_granularity = 1>} : memref<512xf32, 1> -> memref<512xf32, 1>
    frisk.tile_store %rs, %dst : tensor<512xf32>, memref<512xf32, 1>
    return
  }
}