from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,itertools,json,os,random,re,statistics,sys,subprocess
import numpy as np
from gemm_accumulator_slices import read_layouts
from native_gemm_execution import compile_dense_gemm,DenseGemm,NativeGemmImage
root=Path(__file__).parent
cfg=json.loads((root/'design.json').read_text())
focus=tuple(cfg['focus'])
specs=[(g,*s) for s in [focus]+cfg['holdout'] for g in cfg['graphs']]
def shape_ir(g,m,n,k):
 recorded=root/'images'/tag((g,m,n,k))/'input.mlir'
 if recorded.exists():return recorded.read_text()
 from frisk_choices import source
 s=source(f"{'matrix' if g=='matrix' else 'fan'}_m{m}n{n}k{k}").replace('kind = "max"','kind = "sum"')
 if g=='row':
  a,b=s.split(f' -> tensor<{n}xf32>');s=a.replace('dim = 0 : i64','dim = 1 : i64')+f' -> tensor<{m}xf32>'+b.replace(f'{n}xf32',f'{m}xf32').replace(f'input_extents = [{n}]',f'input_extents = [{m}]').replace(f'output_extents = [{4*n}, 8]',f'output_extents = [{4*m}, 8]')
 return s
def tag(case):return '-'.join(map(str,case))
def read_choice(ir):
 mm=next(l for l in ir.splitlines() if ' = frisk.mma ' in l)
 grid=re.search(r'grid = array<i64: (\d+), (\d+)>',mm).groups()
 return 'col' if grid==('1','2') else 'int' if 'row_partition = "interleaved64"' in mm else 'row'
def eligible(ir):
 # Only a candidate row whose intrinsic costs attain the open minimum may enter the oracle.
 raw=re.findall(r'eligible = (true|false), grid = array<i64: (\d+), (\d+)>, local_cost = array<i64: ([^>]+)>, partition = "([^"]+)"',ir)
 result={'col' if a=='1' else 'int' if part=='interleaved64' else 'row':cost for ok,a,b,cost,part in raw if ok=='true'}
 assert result and len(set(result.values()))==1
 return result
def score(ir):
 head=next(l for l in ir.splitlines() if 'frisk.protected_graph = {' in l)
 return {k:int(re.search(r'\b'+k+r' = (\d+) : i64',head)[1]) for k in ['access_units','conversion_units','reduction_units','main_loop_units','distinct_conversions']}
def sig(plan):return [list(o) for o in plan.origins]
def build(case):
 g,m,n,k=case;d=root/'images'/tag(case);d.mkdir(parents=True,exist_ok=True);ir=shape_ir(*case);(d/'input.mlir').write_text(ir)
 old=str(root/'baseline-opt')
 opened=DenseGemm.from_open_layout(ir,k,resident_atoms=1,delivery='dd',frisk_opt=old)
 (d/'before.mlir').write_text(opened.layout_ir);domain=eligible(opened.layout_ir);rec=dict(before=read_choice(opened.layout_ir),domain=domain,arms={})
 for name in domain:
  dd=d/name;dd.mkdir(exist_ok=True)
  partition='interleaved64' if name=='int' else 'contiguous'
  src=ir.replace('policy Auto','policy '+('FullCol' if name=='col' else 'FullRow')).replace('frisk.execution_threads = 256 : i64, k =',f'frisk.row_partition = "{partition}", frisk.execution_threads = 256 : i64, k =')
  pp=DenseGemm.from_open_layout(src,k,resident_atoms=1,delivery='dd',frisk_opt=old)
  assert read_choice(pp.layout_ir)==name and set(eligible(pp.layout_ir).values())==set(domain.values())
  (dd/'solved.mlir').write_text(pp.layout_ir);im,i=compile_dense_gemm(pp);binary=im.asm['cubin'];(dd/'kernel.cubin').write_bytes(binary)
  rec['arms'][name]=dict(score=score(pp.layout_ir),origins=sig(read_layouts(pp.layout_ir)),traffic=i['slice_traffic'],sha256=hashlib.sha256(binary).hexdigest())
  (dd/'info.json').write_text(json.dumps(i))
 (d/'record.json').write_text(json.dumps(rec,indent=2));print('built',tag(case),list(domain),flush=True)
def select(case,opt):
 g,m,n,k=case;d=root/'images'/tag(case);ir=(d/'input.mlir').read_text();rec=json.loads((d/'record.json').read_text())
 o=DenseGemm.from_open_layout(ir,k,resident_atoms=1,delivery='dd',frisk_opt=opt)
 (d/'after.mlir').write_text(o.layout_ir);plan=read_layouts(o.layout_ir)
 assert eligible(o.layout_ir)==rec['domain']
 winner=read_choice(o.layout_ir);assert sig(plan)==rec['arms'][winner]['origins']
 im,i=compile_dense_gemm(o);assert hashlib.sha256(im.asm['cubin']).hexdigest()==rec['arms'][winner]['sha256']
 rec.update(after=winner,newscore=score(o.layout_ir));(d/'choices.json').write_text(json.dumps(rec,indent=2))
 print('selected',tag(case),rec['before'],winner,flush=True)
def time_one(case):
 import torch
 g,m,n,k=case;d=root/'images'/tag(case);rec=json.loads((d/'record.json').read_text());out={}
 for grid in cfg['grids']:
  torch.manual_seed(7352);a=torch.randint(-2,3,(grid,m,k),device='cuda').half();b=torch.randint(-2,3,(grid,k,n),device='cuda').half()
  c=torch.empty(grid,m,n,device='cuda');r=None if g=='matrix' else torch.empty(grid,m if g=='row' else n,device='cuda');ref=a.double()@b.double()
  graphs={}; keep=[]
  for arm in rec['domain']:
   dd=d/arm; info=json.loads((dd/'info.json').read_text());im=NativeGemmImage((dd/'kernel.cubin').read_bytes(),info);keep.append(im)
   launch=im[grid,1,1];launch(a,b,c,r);assert torch.equal(ref,c.double())
   if r is not None:assert torch.equal(r.double(),ref.sum(2 if g=='row' else 1))
   cg=torch.cuda.CUDAGraph()
   with torch.cuda.graph(cg):
    for _ in range(6):launch(a,b,c,r)
   graphs[arm]=cg
  rng=random.Random(553+grid);rows=[]
  for j in range(35):
   order=list(graphs);rng.shuffle(order);row={}
   for arm in order:
    start,end=(torch.cuda.Event(enable_timing=True) for _ in range(2))
    start.record();graphs[arm].replay();end.record();end.synchronize()
    row[arm]=start.elapsed_time(end)*1000/6
   if j>=4: rows.append(row)
  out[grid]=rows
 (d/'paired.json').write_text(json.dumps(out));print('paired',tag(case),flush=True)
if __name__=='__main__':
 step=sys.argv[1]
 if step=='build':
  with ThreadPoolExecutor(4) as pool:list(pool.map(build,specs))
 if step=='select':
  with ThreadPoolExecutor(4) as pool:list(pool.map(lambda c:select(c,os.environ['FRISK_OPT']),specs))
 if step=='time':
  for c in specs:time_one(c)

