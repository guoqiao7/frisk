from study import *
out=[]
for g in cfg['graphs']:
 for grid in (32,132):
  p=DenseGemm.from_open_layout(shape_ir(g,*focus),focus[-1],grid_ctas=grid,sm_count=114)
  plan=read_layouts(p.layout_ir);im,i=compile_dense_gemm(p);arm=read_choice(p.layout_ir)
  path=root/'images'/tag((g,*focus));rec=json.loads((path/'record.json').read_text())
  matches=(hashlib.sha256(im.asm['cubin']).hexdigest()==rec['arms'][arm]['sha256'])
  out.append(dict(graph=g,grid=grid,anchor=arm,contract=plan.slice_contract,delivery=[plan.c_delivery,plan.r_delivery],matches_fixed=matches))
  print(out[-1],flush=True)
(root/'opened.json').write_text(json.dumps(out,indent=2))

