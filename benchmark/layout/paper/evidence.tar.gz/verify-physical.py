import hashlib
import json
import os
import random
import statistics
import sys
from pathlib import Path
from unittest.mock import patch
import torch
import attention_pipeline_selection as aps

root = Path(os.environ["AROOT"])
assert os.environ["CUDA_VISIBLE_DEVICES"] == "GPU-7bafb1de-da7b-3bf6-e8cd-2369e0c92767"
torch.backends.cuda.matmul.allow_tf32 = False
torch.manual_seed(37)
mode, n, h, g, dim, causal, bits = sys.argv[1:]
n,h,g,dim,causal,bits = map(int, (n,h,g,dim,causal,bits))
causal=bool(causal)
opt=os.environ["OPT"]
args=dict(rows=n, heads=h, dim=dim, kv_heads=g, causal=causal, output_bits=bits,
          aligned_inputs=True,row_reciprocal=True,softmax_math="base2-ftz")
static_fn=aps.compile_static_gqa_attention if g<h else aps.compile_static_d64_attention
static_args=dict(args)
if h==g:
    del static_args["dim"],static_args["kv_heads"]
with patch.object(aps,"compile_attention_pipeline",wraps=aps.compile_attention_pipeline) as count:
    static,meta,receipt=static_fn(opt,root/"static",**static_args)
    assert count.call_count==1
chosen=receipt["selected"]
(root/"static-receipt.json").write_text(json.dumps(receipt,indent=2))
q=torch.randn(1,h,n,dim,device="cuda",dtype=torch.float16)
k=torch.randn(1,g,n,dim,device="cuda",dtype=torch.float16)
v=torch.randn_like(k)
scores=q.float()@k.float().repeat_interleave(h//g,dim=1).transpose(-2,-1)/dim**0.5
if causal:
    scores.masked_fill_(torch.ones(n,n,device="cuda",dtype=torch.bool).triu(1),float("-inf"))
reference=scores.softmax(-1)@v.float().repeat_interleave(h//g,dim=1)
def run(im,md):
    out=torch.full(q.shape,float("nan"),device="cuda",dtype=torch.float16 if bits==16 else torch.float32)
    launch=im[tuple(md["grid"])]
    handles={}
    if "k_tensor_map" in md:
        handles["prepared_k"]=im.prepare_k(k)
    if "v_tensor_map" in md:
        handles["prepared_v"]=im.prepare_v(v)
    launch(q,k,v,out,**handles)
    torch.cuda.synchronize()
    error=(out.float()-reference).abs().max().item()
    assert error < (0.004 if bits==16 else 0.002), (md["physical_candidate"],error)
    return out,error,lambda:launch(q,k,v,out,**handles)
static_out,static_error,_=run(static,meta)
record=dict(case=[n,h,g,dim,causal,bits],mode=mode,static=chosen,ranked_family=receipt["ranked_family"],
            static_compiles=1,static_error=static_error)
def hfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
print("STATIC", chosen, flush=True)
def measure(images):
    assert chosen in images, (chosen, list(images))
    sm=meta; tm=images[chosen][1]
    for key in ("physical_candidate","physical_contract_sha256","execution_audit","grid","dynamic_shared_bytes"):
        assert sm[key]==tm[key], key
    for file in ("input.mlir","execution.json","kernel.ptx","kernel.cubin"):
        assert hfile(root/"static"/file)==hfile(root/"tune"/chosen/file),file
    captured=[]
    graphs={}
    errors={}
    for name,(im,md) in images.items():
        out,errors[name],launch=run(im,md)
        if name==chosen: assert torch.equal(out,static_out)
        captured.append((out,launch))
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for _ in range(12):launch()
        graphs[name]=graph
    order=list(images);rng=random.Random(13)
    samples=[]
    for _ in range(4):
        rng.shuffle(order)
        for permutation in (order, order[::-1]):
            row={}
            for name in permutation:
                begin,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                graphs[name].replay();begin.record()
                for __ in range(6):graphs[name].replay()
                end.record();end.synchronize();row[name]=begin.elapsed_time(end)*1000/72
            samples.append(row)
    record.update(admitted=len(images),numeric_errors=errors,paired_samples_us=samples,
        cubin_sha256=sm["execution_audit"]["cubin_sha256"],layout_sha256=sm["execution_audit"]["layout_sha256"],
        physical_contract_sha256=sm["physical_contract_sha256"],bitwise_equal=True,
        v_map={n:m.get("v_tensor_map",{}).get("swizzle_bytes") for n,(_,m) in images.items()})
    return samples
compile_actual=aps.compile_attention_pipeline
def compile_subset(plan, *a, **kw):
    if mode=="selected" and plan.name!=chosen:raise ValueError("outside selected-only verification")
    return compile_actual(plan,*a,**kw)
with patch.object(aps,"compile_attention_pipeline",side_effect=compile_subset):
    im,md,result=aps.tune_attention_pipelines(opt,root/"tune",measure=measure,**args)
record.update(tuning=result)
(root/"results.json").write_text(json.dumps(record,indent=2))
print("PASS",chosen,result["selected"],record["admitted"],len(result["rejected"]), flush=True)
