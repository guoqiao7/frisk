from pathlib import Path
import sys,os,importlib.util,importlib.abc,unittest
p=Path(__file__).parent;repo=Path('/home/baopeihua/frisk')
live=repo/'benchmark/layout/execution';frozen=p/'baseline-python/benchmark/layout/execution'
# The archived calibration receipts bind absolute source paths. Resolve Python code
# from the baseline while preserving those original filenames and artifact locations.
class Baseline(importlib.abc.MetaPathFinder,importlib.abc.Loader):
 def find_spec(self,name,path,target=None):
  if '.' not in name and (frozen/(name+'.py')).is_file():
   return importlib.util.spec_from_file_location(name,live/(name+'.py'),loader=self)
 def create_module(self,spec):return None
 def exec_module(self,module):
  src=frozen/(module.__name__+'.py')
  exec(compile(src.read_bytes(),module.__file__,'exec'),module.__dict__)
sys.meta_path.insert(0,Baseline())
s=(p/'units.py').read_text();s=s.replace("suite=unittest.defaultTestLoader.discover(str(ex))","suite=unittest.defaultTestLoader.loadTestsFromNames(['test_compatible_native_profiles','test_hybrid_demand','test_demand_observer','test_export'])")
exec(compile(s,str(p/'units.py'),'exec'))
