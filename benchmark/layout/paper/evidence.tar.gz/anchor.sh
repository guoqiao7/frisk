set -euo pipefail
p=$(cd "$(dirname "$0")" && pwd)
source "$p/environment.sh"
cd "$p/anchor"
python -u choose.py >"$p/anchor-choice.log" 2>&1
python -u study.py time >"$p/anchor-time.log" 2>&1
