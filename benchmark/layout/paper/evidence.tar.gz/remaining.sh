set -eo pipefail
p=$(cd "$(dirname "$0")" && pwd)
source "$p/environment.sh"
(
source /data0/baopeihua/frisk-gqa-resident-w7a5Iz/env.sh
export CUDA_VISIBLE_DEVICES=GPU-7bafb1de-da7b-3bf6-e8cd-2369e0c92767 PYTHONPATH="/home/baopeihua/frisk/benchmark/layout/execution:$PYTHONPATH"
cd "$p/sweep"
for x in mha64 gqa64 mha128; do python -u fabench.py "$x"; done
) >"$p/fa-bench.log" 2>&1
(cd "$p/fa3-guard"; export OPT="$FRISK_OPT"; python -u recheck.py) >"$p/fa3-guard.log" 2>&1
(cd "$p/factorial"; for g in 1 2; do s=8141; if test "$g" = 2; then s=8935; fi; PAIR_SEED=$s python -u bench.py "pairs$g" matrix_m256n512k256 fan_m256n512k256 row_m256n512k256 || exit 1; done) >"$p/factorial.log" 2>&1
(cd "$p/norm"; export PRIOR=/data0/baopeihua/frisk-norm-grid-QbfW34 AUDIT=/data0/baopeihua/frisk-rms-grid-audit-sDaUby E=/home/baopeihua/frisk/benchmark/layout/execution; export PYTHONPATH="$PRIOR:$p/sweep:/data0/baopeihua/frisk-wg-reduction-cbgWtK:$E:/home/baopeihua/tilelang:/home/baopeihua/tilelang/3rdparty/tvm/python"; python -u run.py public && python -u -c 'import run as r; c=r.spec["target"]; [r.measure(c,v,0,r.read(r.D/"decisions.json")) for v in r.configs(c)]') >"$p/norm.log" 2>&1
(cd "$p/sweep"; python -u point.py) >"$p/point.log" 2>&1
