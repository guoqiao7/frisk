from pathlib import Path
import hashlib,json,csv
p=Path(__file__).resolve().parent
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def dump(n,value):(p/n).write_text(json.dumps(value,sort_keys=True,indent=2))
w=Path('/data0/baopeihua/frisk-writeback-issue-lbDoId')
identities={}
for r in csv.DictReader((p/'factorial/corrected-selection.csv').open()):
 case=r['graph']+'_m256n512k256';k=r['after']
 measured=p/'factorial/images'/case/k/'kernel.cubin'
 corrected=w/'images'/case/k/'kernel.cubin'
 a,b=map(digest,(measured,corrected));assert a==b
 identities[case+'/'+k]=dict(measured=a,corrected=b)
dump('factorial/image-identity.json',identities)
old=json.loads((p/'c2-replay/images.json').read_text());assert all(digest(p/'c2-replay/images'/a/'kernel.cubin')==v['cubin'] for a,v in old.items())
plans=json.loads((p/'c2-replay/plans.json').read_text())
groups={}
for k,v in plans.items():
 mode,op=k.split('-')[1:3]
 if 'maps' not in v:continue
 ident=(mode,op,v['grid'],json.dumps(v['maps'],sort_keys=True))
 groups.setdefault(ident,set()).add(old[k]['cubin'])
mismatches=[list(k[:3]) for k,v in groups.items() if len(v)>1]
dump('c2-replay/hash-check.json',dict(images=len(old),groups=len(groups),identity_exceptions=mismatches))
fixed={}
for r in sorted((p/'fa-fixed/fixed').glob('*/*/receipt.json')):
 h=digest(r.parent/'kernel.cubin');record=json.loads(r.read_text());assert h==record['cubin']
 fixed[str(r.parent.relative_to(p/'fa-fixed/fixed'))]=record
dump('fa-fixed/image-receipts.json',fixed)
print(len(identities),len(old),len(groups),mismatches,len(fixed))
