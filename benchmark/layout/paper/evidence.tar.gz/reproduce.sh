#!/usr/bin/env bash
# Run on the original H100 host with the paper checkout and archived compiler images.
set -euo pipefail
src=$(cd "$(dirname "$0")" && pwd)
base=/data0/baopeihua
out=$(mktemp -d "$base/frisk-paper-repeat-XXXXXX")
printf 'Experiment directory %s\n' "$out"
for path in sweep/data sweep/fa sweep/gem sweep/logs sweep/point sweep/fusion factorial/results norm/public norm/raw fa3-guard fa-fixed/fixed c2-replay components/inputs components/results anchor/images; do mkdir -p "$out/$path"; done
for file in environment.sh anchor.sh physical.sh counters.sh replay.sh remaining.sh freeze-images.py summarize.py units.py verify-physical.py; do cp "$src/$file" "$out/"; done
cp "$src"/sweep/{design.json,point-design.json,fusion-design.json,timing.py,fusion.py,point.py,gemrun.py,faprep.py,fabench.py,run.sh} "$out/sweep/"
cp "$src"/norm/{design.json,decisions.json,run.py,threeway.py} "$out/norm/"
cp "$src"/factorial/{bench.py,fixtures.py,qualify_gemm_standalone.py,registration.json,selections.json,four-arms.csv,corrected-selection.csv} "$out/factorial/"
cp "$src/fa3-guard/recheck.py" "$out/fa3-guard/"
cp "$src"/fa-fixed/{fixed_run.py,fixed_build.py,benchlib.py} "$out/fa-fixed/"
cp "$src"/c2-replay/{bench3.py,maps.py,images.json,plans.json} "$out/c2-replay/"
cp "$src"/components/{cases.py,c2_mix.py} "$out/components/"; cp "$src/components/inputs/both.mlir" "$out/components/inputs/"
cp "$src"/anchor/{design.json,choose.py,study.py,opened.py} "$out/anchor/"
ln -s "$base/frisk-consumer-factorial-F2M8TE/images" "$out/factorial/images"
ln -s "$base/frisk-mixed-layout-BwwI1q/before" "$out/components/before"
ln -s "$base/frisk-fa3-guarded-query-Ck53Q5/193-193-h4-g1-c0" "$out/fa3-guard/"
for k in images dependencies; do ln -s "$base/frisk-c2-threeway-ipPDZp/$k" "$out/c2-replay/"; done
for d in "$base"/frisk-fa-two-studies-tCb9oq/fixed/*; do if test -d "$d"; then ln -s "$d" "$out/fa-fixed/fixed/"; fi; done
for d in "$base"/frisk-anchor-rank-JNpwdp/images/*; do
 j="$out/anchor/images/${d##*/}"; mkdir "$j"; cp "$d"/{record.json,input.mlir} "$j/"
 for k in col row int; do if test -d "$d/$k"; then ln -s "$d/$k" "$j/$k"; fi; done
done
source "$out/environment.sh"
test "$CUDA_VISIBLE_DEVICES" = "$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)"
if test "${1:-}" = --prepare-only; then exit; fi
repo=/home/baopeihua/frisk
ninja -C "$repo/build-m6-release" frisk-opt frisk_layout_tool check-frisk >"$out/lit.log" 2>&1
(cd "$out/components"; python -u c2_mix.py; python -u cases.py) >"$out/components.log"
bash "$out/sweep/run.sh" >"$out/sweep.log" 2>&1
(cd "$out/sweep"; python -u faprep.py) >"$out/fa-prep.log" 2>&1
bash "$out/remaining.sh"
(
 cd "$out/norm"; export PRIOR="$base/frisk-norm-grid-QbfW34" E="$repo/benchmark/layout/execution" AUDIT="$base/frisk-rms-grid-audit-sDaUby"
 export PYTHONPATH="$PRIOR:$out/sweep:$base/frisk-wg-reduction-cbgWtK:$E:/home/baopeihua/tilelang:/home/baopeihua/tilelang/3rdparty/tvm/python"
 python -u threeway.py
) >"$out/norm-threeway.log" 2>&1
bash "$out/replay.sh" >"$out/replay.log" 2>&1
bash "$out/counters.sh" >"$out/counters.log" 2>&1
bash "$out/physical.sh"
bash "$out/anchor.sh"
(cd "$out/anchor"; python -u opened.py) >"$out/anchor-open.log"
python "$out/freeze-images.py"
python "$out/summarize.py"
