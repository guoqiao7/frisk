import os,json,re,subprocess
from cases import D,ROOT
c2=ROOT/'test/Transforms/multi-anchor-integer.mlir'
text=c2.read_text()
both=(D/'inputs/both.mlir').read_text()
aliases=both[:both.index('module attributes')]
tr=both[both.index('      %a ='):both.index('      %ri =')]
tr=tr.replace('%in ', '%ta ').replace('%out ', '%tb ')
block='''    %ta = memref.alloc() {alignment=128:i64} : memref<64x16xf32, 1>
    %tb = memref.alloc() {alignment=128:i64} : memref<64x16xf32, 1>
    frisk.storage_contract %ta {layout=#row} : memref<64x16xf32, 1>
    frisk.storage_contract %tb {layout=#col} : memref<64x16xf32, 1>
    "frisk.parallel"() <{ranges=array<i64:1>,threads=128:i64}> ({
    ^bb0(%ti:index):
'''+tr+'''      frisk.end
    }) : () -> ()
'''
block=block[:block.index('    "frisk.parallel"')]+tr
def kernel(body):
 return aliases+'''module attributes {frisk.target="sm_90a"} {
  "frisk.kernel"() <{sym_name="mixed",function_type=()->()}> ({
    "frisk.parallel"() <{ranges=array<i64:1>,threads=256:i64}> ({
    ^bb0(%ti:index):
'''+body+'''      frisk.end
    }) : () -> ()
    frisk.end
  }) : () -> ()
}
'''
def receipt(ir, name, opt):
 inp=D/'inputs'/f'c2-{name}.mlir';inp.write_text(ir);dst=D/'results'/f'c2-{name}.mlir'
 subprocess.run([str(opt),str(inp),'--frisk-protected-store-layout=anchor-solver=integer integer-global-access=native','-verify-each','-o',str(dst)],check=True)
 out=dst.read_text();r=re.search(r'anchors = \[\[(.*?)\]\],',out)
 eligible=[] if r is None else [(int(a),int(b)) for a,b in re.findall(r'eligible = true, grid = array<i64: (\d+), (\d+)>',r[1])]
 z=[int(re.search(r'\b'+key+r' = (\d+)',out)[1]) for key in ('access_units','main_loop_units','reduction_units','conversion_units','distinct_conversions')]
 return eligible,z
new=ROOT/'build-m6-release/bin/frisk-opt'
_,trans=receipt(kernel(block),'isolated-transpose',new)
print('transpose 256 threads',trans,flush=True)
for typ in ['ss','rs']:
 s=text.split('//--- '+typ+'.mlir\n')[1].split('//---')[0]
 g=s.split('func.func @selection() {',1)[1].split('    return',1)[0]
 vals={}
 for kind,ir in [('baseline',s),('fixed',s),('kernel',kernel(g)),('mma-first',kernel(g+block)),('mma-last',kernel(block+g))]:
  eligible,z=receipt(ir,typ+'-'+kind,D/'before/frisk-opt' if kind=='baseline' else new)
  assert eligible==([(1,2),(2,1)] if typ=='ss' else [(2,1)]),eligible
  vals[kind]=z
  print(typ,kind,eligible,z,flush=True)
  if kind=='fixed':assert z==vals['baseline']
  if kind.startswith('mma-'): assert z==[x+y for x,y in zip(vals['kernel'],trans)]
