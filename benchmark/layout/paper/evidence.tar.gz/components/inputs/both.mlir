#vec = #frisk.storage<map=#frisk.affine_layout<inputs=["dim0"],input_extents=[16],outputs=["byte_offset","bit_offset"],output_extents=[64,8],map=affine_map<(i)->(i*4,0)>>,memory_space=#frisk<memory_space Global>,alignment=128,vector_granularity=1>
#row = #frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[64,16],outputs=["byte_offset","bit_offset"],output_extents=[4096,8],map=affine_map<(i,j)->(i*64+j*4,0)>>,memory_space=#frisk<memory_space Global>,alignment=128,vector_granularity=1>
#col = #frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[64,16],outputs=["byte_offset","bit_offset"],output_extents=[4096,8],map=affine_map<(i,j)->(j*256+i*4,0)>>,memory_space=#frisk<memory_space Global>,alignment=128,vector_granularity=1>
module attributes {frisk.target="sm_90a"} {
  "frisk.kernel"() <{sym_name="transpose",function_type=(memref<64x16xf32, 1>,memref<64x16xf32, 1>,memref<64x16xf32, 1>,memref<16xf32, 1>)->()}> ({
  ^bb0(%in:memref<64x16xf32, 1>,%out:memref<64x16xf32, 1>,%rin:memref<64x16xf32, 1>,%rout:memref<16xf32, 1>):
    frisk.storage_contract %in {layout=#row} : memref<64x16xf32, 1>
    frisk.storage_contract %out {layout=#col} : memref<64x16xf32, 1>
    frisk.storage_contract %rin {layout=#row} : memref<64x16xf32, 1>
    frisk.storage_contract %rout {layout=#vec} : memref<16xf32, 1>
    "frisk.parallel"() <{ranges=array<i64:1>,threads=128:i64}> ({
    ^bb0(%i:index):
      %a = frisk.layout_view %in {layout=#row} : memref<64x16xf32, 1> -> memref<64x16xf32, 1>
      %b = frisk.layout_view %out {layout=#col} : memref<64x16xf32, 1> -> memref<64x16xf32, 1>
      %x = frisk.tile_load %a : memref<64x16xf32, 1> -> tensor<64x16xf32>
      frisk.tile_store %x, %b : tensor<64x16xf32>, memref<64x16xf32, 1>
      %ri = frisk.layout_view %rin {layout=#row} : memref<64x16xf32, 1> -> memref<64x16xf32, 1>
      %ro = frisk.layout_view %rout {layout=#vec} : memref<16xf32, 1> -> memref<16xf32, 1>
      %rx = frisk.tile_load %ri : memref<64x16xf32, 1> -> tensor<64x16xf32>
      %rr = frisk.reduce_tensor %rx {dim = 0 : i64, frisk.execution_threads = 128 : i64, kind = "sum"} : tensor<64x16xf32> -> tensor<16xf32>
      frisk.tile_store %rr, %ro : tensor<16xf32>, memref<16xf32, 1>
      frisk.end
    }) : () -> ()
    frisk.end
  }) : () -> ()
}
