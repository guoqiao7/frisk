from pathlib import Path
import re,json,os,subprocess,csv,concurrent.futures,hashlib
D=Path(__file__).resolve().parent
ROOT=Path('/home/baopeihua/frisk')
shapes=[(64,16),(32,16),(16,128),(128,16),(32,32),(64,32),(128,32),(32,128),(64,64)]
layouts=['tr','red','tr-red','red-tr']
t=(D/'inputs/both.mlir').read_text();i=t.index('      %a =');j=t.index('      %ri =');k=t.index('      frisk.end',j)
def source(m,n,order):
 import string
 sections={'tr':t[i:j],'red':t[j:k]}
 s=t[:i]+''.join(sections[x] for x in order.split('-'))+t[k:]
 for a,b in [('output_extents=[64,8]',f'output_extents=[{n*4},8]'),('output_extents=[4096,8]',f'output_extents=[{m*n*4},8]'),('[64,16]',f'[{m},{n}]'),('input_extents=[16]',f'input_extents=[{n}]'),('i*64+j*4',f'i*{n*4}+j*4'),('j*256+i*4',f'j*{m*4}+i*4'),('<16xf32',f'<{n}xf32'),('<64x16xf32',f'<{m}x{n}xf32')]:s=s.replace(a,b)
 return s
def solve(job):
 m,n,order,mode,version=job
 inp=D/'inputs'/f'{m}x{n}-{order}.mlir';dest=D/'results'/f'{m}x{n}-{order}-{mode}-{version}.mlir'
 sf=D/'before/frisk-opt' if version=='old' else ROOT/'build-m6-release/bin/frisk-opt'
 subprocess.run([str(sf),str(inp),f'--frisk-protected-store-layout=anchor-solver=integer integer-global-access={mode}','-verify-each','-o',str(dest)],check=True,stdout=subprocess.DEVNULL)
 s=dest.read_text()
 def val(k):return int(re.search(r'\b'+k+r' = (\d+)',s)[1])
 z={k:val(k) for k in ['access_units','conversion_units','reduction_units','main_loop_units','distinct_conversions']}
 z['total']=sum(z[k] for k in ['access_units','conversion_units','reduction_units','main_loop_units']);z['ops']=len(re.findall(r' = frisk\.convert_layout ',s))
 assert 'optimal = true' in s and z['ops']==z['distinct_conversions']
 return dict(m=m,n=n,order=order,mode=mode,version=version,**z)
if __name__=='__main__':
 jobs=[]
 for m,n in shapes:
  for order in layouts:
   (D/'inputs'/f'{m}x{n}-{order}.mlir').write_text(source(m,n,order))
   for mode in ('native','pointwise','scalar'):
    for version in (('new','old') if mode=='native' else ('new',)):
     jobs.append((m,n,order,mode,version))
 with concurrent.futures.ThreadPoolExecutor(4) as pool:allrows=list(pool.map(solve,jobs))
 with (D/'results.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=allrows[0]);w.writeheader();w.writerows(allrows)
 for m,n in shapes:
  def rr(md,v):return {r['order']:r for r in allrows if (r['m'],r['n'],r['version'],r['mode'])==(m,n,v,md)}
  for mode in ('native','pointwise','scalar'):
   arms=rr(mode,'new')
   for k in ('total','distinct_conversions'):
    assert arms['tr-red'][k]==arms['red-tr'][k]==arms['tr'][k]+arms['red'][k],(m,n,mode,k,arms)
  a=rr('native','new');b=rr('native','old');print(m,n,b['tr-red']['total'],a['tr-red']['total'],a['red-tr']['total'],a['tr']['total'],a['red']['total'],flush=True)
