import json,os
from pathlib import Path
from unittest.mock import patch
from native_fa3_execution import compile_static_fa3,compile_budgeted_fa3
import backend,torch
p=Path(__file__).resolve().parent
plan='/data0/baopeihua/baopeihua-overlap-fa3-516-615-20261111-vHOwfq/history/schedule_00615.json'
args=dict(rows=193,heads=4,causal=False)
opt=os.environ['OPT']
with patch('native_fa3_execution.solve_overlap_fa3',side_effect=AssertionError('bulk tail reached solver')):
    for tile in (64,128,None):
        try:compile_static_fa3(plan,opt,p/'reject',query_tile=tile,fa3_writeback='tma',**args)
        except ValueError as e:assert 'guarded register writer' in str(e)
        else:raise AssertionError('unsafe writer admitted')
with patch.object(backend,'compile_execution',wraps=backend.compile_execution) as c:
    images,r=compile_static_fa3(plan,opt,p/'final-default',**args)
    assert c.call_count==1 and r['score_domain']==r['geometry']['score_domain']=='ordinary_mha_partial_q_extrapolation'
a=r['selected'][0]; im,md=images[a]
old=json.loads((p/'193-193-h4-g1-c0/auto/metadata.json').read_text())
assert old['execution_audit']['cubin_sha256']==md['execution_audit']['cubin_sha256']
torch.manual_seed(4711)
q,k,v=[torch.randn(1,4,193,128,device='cuda',dtype=torch.float16) for _ in range(3)]
o=torch.full_like(q,float('nan'))
im[tuple(md['grid'])](q,k,v,o)
ref=(q.float()@k.float().transpose(-2,-1)/128**0.5).softmax(-1)@v.float()
assert torch.allclose(o.float(),ref,atol=.001,rtol=.001)
err=float((o.float()-ref).abs().max())
data=json.loads((p/'final-default/execution.json').read_text())
with patch.object(backend,'compile_execution',wraps=backend.compile_execution) as c:
    pair,rr=compile_budgeted_fa3(data,budget=2,directory=p/'budget2',fa3_writeback='auto')
    assert c.call_count==len(pair)==2 and len(rr['layout_proofs'])==1
    for img,m in pair.values():
        assert m['writeback']=='register'
        o.fill_(float('nan'));img[tuple(m['grid'])](q,k,v,o)
        assert torch.allclose(o.float(),ref,atol=.001,rtol=.001)
print('PASS',a,r['transport_cost_included_in'],rr['selected'],err,flush=True)
