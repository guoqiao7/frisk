# Server inputs for the GPU0 reproduction

All paths below the data root use /data0/baopeihua. The backend and the compiler binary come from /home/baopeihua/frisk. For the environment in use at collection time see validation.json. The CPU solver certificate and the GPU execution/timing have separate receipts.

| Evidence | External input retained for hardware replay |
| --- | --- |
| C2 | frisk-c2-threeway-ipPDZp images, plans, native-source maps and CUDA driver helper; frisk-mixed-layout-BwwI1q/before for the pre-fix score |
| Whole-graph normalization | frisk-norm-grid-QbfW34, frisk-norm-reuse-dzKwDh, frisk-rms-grid-audit-sDaUby, frisk-norm-neartie-O8a55T and their checked replay dependencies |
| Copy, transpose, two stores | frisk-vector-access-o2wm17 and frisk-pointwise-integer-L7Rih8; maps extracted from the external implementations |
| GEMM/ReGLU | frisk-cross-sweep-fcOfel replay scripts, frisk-loop-layout-U7RAo8 and each map/image manifest referenced by fusion.py; archived native baseline images referenced by gemrun.py |
| GEMM anchor and four-arm evidence | frisk-anchor-rank-JNpwdp, frisk-consumer-factorial-F2M8TE and frisk-writeback-issue-lbDoId; the factorial covers the continuous-anchor experiment and the native anchor test also admits the interleaved partition |
| Fixed D64 FA | frisk-fa-two-studies-tCb9oq/fixed; image-receipts.json contains the map/cubin receipts used for all 108 arms |
| Native FA | frisk-fa-shape-sweep-OI7QjD, frisk-gqa-resident-w7a5Iz, frisk-fa-joint-cIk02C; scorer and compiler from the current paper source, peer arms from the recorded validated pools |
| Partial-Q and physical-plan gates | frisk-fa3-guarded-query-Ck53Q5, frisk-physical-plans-VcHLUH, frisk-twoq-kv64-ewXyMu, the FA3 #615 plan and the runtime named by the receipts |

environment.sh sources the maintained H100 runner environment; some archived wrappers import earlier runner trees by absolute path. Their directory names carry provenance. Frozen peers are freshly timed, with build identity where recorded; third-party compilers are not all rebuilt on every run. Hardware reproduction requires the archived trees. For offline review the raw paired blocks, identities, selection fields and summarize.py are sufficient.
