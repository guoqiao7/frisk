from pathlib import Path
import hashlib,json,random,statistics
import numpy as np
def dump(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);f=p.with_suffix('.partial');f.write_text(json.dumps(v));f.replace(p)
def read(p):return json.loads(Path(p).read_text())
def paired(graphs,pools,static,tag,reps=6):
 import torch
 seed=71823+int(hashlib.sha256(tag.encode()).hexdigest()[:7],16);rng=random.Random(seed)
 def blocks(keys,n):
  rows=[]
  for j in range(n):
   order=list(keys);rng.shuffle(order);r={}
   for key in order:
    a,b=(torch.cuda.Event(enable_timing=True) for _ in range(2));a.record();graphs[key].replay();b.record();b.synchronize();r[key]=a.elapsed_time(b)*1000/reps
   rows.append(r)
  return rows
 blocks(graphs,3);screen=blocks(graphs,11);picks={e:min(ids,key=lambda k:statistics.median(r[k] for r in screen)) for e,ids in pools.items()}
 keys=list(dict.fromkeys([static,*picks.values()]));rows=blocks(keys,33)
 return dict(static=static,pools=pools,screen=screen,picks=picks,samples=rows)

