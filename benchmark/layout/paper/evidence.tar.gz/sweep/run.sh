set -eo pipefail
root=$(cd "$(dirname "$0")" && pwd)
source "$root/../environment.sh"
cd "$root"
python -u - <<'PY'
import torch,os
assert os.environ['CUDA_VISIBLE_DEVICES']=='GPU-7bafb1de-da7b-3bf6-e8cd-2369e0c92767'
print(torch.cuda.get_device_properties(0))
PY
python -u fusion.py
python -u gemrun.py prep matrix_m128n512k240 fan_m128n512k240
python -u gemrun.py bench matrix_m128n512k240 fan_m128n512k240
