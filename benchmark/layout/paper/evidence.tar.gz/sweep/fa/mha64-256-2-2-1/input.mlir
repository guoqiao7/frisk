module attributes {frisk.execution_contract={version=1:i64,kind="single",cta=128:i64,groups=[{base=0:i64,threads=128:i64}],roles={q=0:i64,k=0:i64,v=0:i64,qk=0:i64,pv=0:i64,reduce=0:i64},buffers={q={versions=1:i64},k={versions=1:i64},v={versions=1:i64}},publication="cta_barrier",batch=4:i64,wait_pending=0:i64},frisk.target="sm_90a", frisk.online_launch={rows=256:i64,heads=2:i64,kv_heads=2:i64,causal=true}} {
"frisk.kernel"() <{sym_name="native_online",function_type=(memref<64x64xf16,1>,memref<128x64xf16,1>,memref<128x64xf16,1>,memref<64x64xf32,1>)->()}> ({
^bb0(%Q:memref<64x64xf16,1>,%K0:memref<128x64xf16,1>,%V0:memref<128x64xf16,1>,%O:memref<64x64xf32,1>):
frisk.storage_contract %Q {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[64,64],outputs=["byte_offset","bit_offset"],output_extents=[8192,8],map=affine_map<(i,j)->((i*128+j*2),0)>>,memory_space=#frisk<memory_space Global>,alignment=1,vector_granularity=1>} : memref<64x64xf16,1>
frisk.storage_contract %K0 {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[128,64],outputs=["byte_offset","bit_offset"],output_extents=[16384,8],map=affine_map<(i,j)->((i*128+j*2),0)>>,memory_space=#frisk<memory_space Global>,alignment=1,vector_granularity=1>} : memref<128x64xf16,1>
frisk.storage_contract %V0 {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[128,64],outputs=["byte_offset","bit_offset"],output_extents=[16384,8],map=affine_map<(i,j)->((i*128+j*2),0)>>,memory_space=#frisk<memory_space Global>,alignment=1,vector_granularity=1>} : memref<128x64xf16,1>
frisk.storage_contract %O {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[64,64],outputs=["byte_offset","bit_offset"],output_extents=[16384,8],map=affine_map<(i,j)->((i*256+j*4),0)>>,memory_space=#frisk<memory_space Global>,alignment=128,vector_granularity=1>} : memref<64x64xf32,1>
%qs = memref.alloc() {alignment=1024:i64} : memref<64x64xf16,3>
%ks = memref.alloc() {alignment=1024:i64} : memref<128x64xf16,3>
%vs = memref.alloc() {alignment=1024:i64} : memref<128x64xf16,3>
"frisk.parallel"() <{ranges=array<i64:1>,threads=128:i64}> ({
^bb0(%i:index):
%gQ = frisk.layout_view %Q : memref<64x64xf16,1> -> memref<64x64xf16,1>
%sqs = frisk.layout_view %qs {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[64,64],outputs=["byte_offset","bit_offset"],output_extents=[8192,8],map=affine_map<(i,j)->(((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192)+(((((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 16) mod 2)+((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 128) mod 2)) mod 2)-((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 16) mod 2))*16+(((((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 32) mod 2)+((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 256) mod 2)) mod 2)-((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 32) mod 2))*32+(((((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 64) mod 2)+((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 512) mod 2)) mod 2)-((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*8192) floordiv 64) mod 2))*64,0)>>,memory_space=#frisk<memory_space Shared>,alignment=1024,vector_granularity=1>} : memref<64x64xf16,3> -> memref<64x64xf16,3>
%gK0 = frisk.layout_view %K0 : memref<128x64xf16,1> -> memref<128x64xf16,1>
%sks = frisk.layout_view %ks {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[128,64],outputs=["byte_offset","bit_offset"],output_extents=[16384,8],map=affine_map<(i,j)->(((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384)+(((((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 16) mod 2)+((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 128) mod 2)) mod 2)-((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 16) mod 2))*16+(((((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 32) mod 2)+((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 256) mod 2)) mod 2)-((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 32) mod 2))*32+(((((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 64) mod 2)+((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 512) mod 2)) mod 2)-((((i mod 8)*128+(i floordiv 8)*1024+(j mod 64)*2+(j floordiv 64)*16384) floordiv 64) mod 2))*64,0)>>,memory_space=#frisk<memory_space Shared>,alignment=1024,vector_granularity=1>} : memref<128x64xf16,3> -> memref<128x64xf16,3>
%gV0 = frisk.layout_view %V0 : memref<128x64xf16,1> -> memref<128x64xf16,1>
%svs = frisk.layout_view %vs {layout=#frisk.storage<map=#frisk.affine_layout<inputs=["dim0","dim1"],input_extents=[128,64],outputs=["byte_offset","bit_offset"],output_extents=[16384,8],map=affine_map<(i,j)->(((j mod 16)*2+(j floordiv 16)*256+(i mod 8)*32+(i floordiv 8)*1024)+(((((((j mod 16)*2+(j floordiv 16)*256+(i mod 8)*32+(i floordiv 8)*1024) floordiv 16) mod 2)+((((j mod 16)*2+(j floordiv 16)*256+(i mod 8)*32+(i floordiv 8)*1024) floordiv 128) mod 2)) mod 2)-((((j mod 16)*2+(j floordiv 16)*256+(i mod 8)*32+(i floordiv 8)*1024) floordiv 16) mod 2))*16,0)>>,memory_space=#frisk<memory_space Shared>,alignment=1024,vector_granularity=1>} : memref<128x64xf16,3> -> memref<128x64xf16,3>
%gO = frisk.layout_view %O : memref<64x64xf32,1> -> memref<64x64xf32,1>
frisk.copy %gQ[], %sqs[] {frisk.execution_threads=128:i64,frisk.execution_layout=#frisk.distributed<map=#frisk.bit_linear<inputs=["register","lane","warp"],input_bits=[5,5,2],outputs=["dim0","dim1"],output_bits=[6,6],matrix=dense<[[0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]]>:tensor<12x12xi1>>,topology=[32,32,4,1,1],replication=1>,frisk.writer_policy="first_owner",frisk.vector_bytes=1:i64,srcExtents=array<i64:64,64>,dstExtents=array<i64:64,64>} : memref<64x64xf16,1>, memref<64x64xf16,3>
%zeroO = arith.constant dense<0.0> : tensor<64x64xf32>
%zero = arith.constant dense<0.0> : tensor<64x128xf32>
%zeroR = arith.constant dense<0.0> : tensor<64xf32>
%scale = arith.constant dense<0x3E38AA3B> : tensor<64x128xf32>
%emptyO = tensor.empty() : tensor<64x64xf32>
%empty = tensor.empty() : tensor<64x128xf32>
%neg = arith.constant dense<0xFF800000> : tensor<64xf32>
%idx0 = arith.constant 0 : index
%idx1 = arith.constant 1 : index
%bound = arith.constant 2 : index
%mfinal,%lfinal,%ofinal = scf.for %iv = %idx0 to %bound step %idx1 iter_args(%carryM=%neg,%carryL=%zeroR,%carryO=%zeroO) -> (tensor<64xf32>,tensor<64xf32>,tensor<64x64xf32>) {
frisk.copy %gK0[], %sks[] {frisk.execution_threads=128:i64,frisk.execution_layout=#frisk.distributed<map=#frisk.bit_linear<inputs=["register","lane","warp"],input_bits=[6,5,2],outputs=["dim0","dim1"],output_bits=[7,6],matrix=dense<[[0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]]>:tensor<13x13xi1>>,topology=[64,32,4,1,1],replication=1>,frisk.writer_policy="first_owner",frisk.vector_bytes=1:i64,srcExtents=array<i64:128,64>,dstExtents=array<i64:128,64>} : memref<128x64xf16,1>, memref<128x64xf16,3>
frisk.copy %gV0[], %svs[] {frisk.execution_threads=128:i64,frisk.execution_layout=#frisk.distributed<map=#frisk.bit_linear<inputs=["register","lane","warp"],input_bits=[6,5,2],outputs=["dim0","dim1"],output_bits=[7,6],matrix=dense<[[0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]]>:tensor<13x13xi1>>,topology=[64,32,4,1,1],replication=1>,frisk.writer_policy="first_owner",frisk.vector_bytes=1:i64,srcExtents=array<i64:128,64>,dstExtents=array<i64:128,64>} : memref<128x64xf16,1>, memref<128x64xf16,3>
%s1 = "frisk.mma"(%sqs,%sks,%zero) {m=64:i64,n=128:i64,k=64:i64,frisk.execution_threads=128:i64,policy=#frisk<gemm_warp_policy FullRow>,trans_b=true} : (memref<64x64xf16,3>,memref<128x64xf16,3>,tensor<64x128xf32>) -> tensor<64x128xf32>
%x1 = arith.mulf %s1, %scale : tensor<64x128xf32>
%mx1 = frisk.reduce_tensor %x1 {kind="max",dim=1:i64,frisk.execution_threads=128:i64} : tensor<64x128xf32> -> tensor<64xf32>
%newM1 = arith.maximumf %carryM, %mx1 : tensor<64xf32>
%diff1 = arith.subf %carryM, %newM1 : tensor<64xf32>
%alpha1 = math.exp2 %diff1 : tensor<64xf32>
%ba1 = linalg.broadcast ins(%alpha1 : tensor<64xf32>) outs(%emptyO : tensor<64x64xf32>) dimensions = [1]
%acc1 = arith.mulf %carryO, %ba1 : tensor<64x64xf32>
%lscaled1 = arith.mulf %carryL, %alpha1 : tensor<64xf32>
%bm1 = linalg.broadcast ins(%newM1 : tensor<64xf32>) outs(%empty : tensor<64x128xf32>) dimensions = [1]
%dx1 = arith.subf %x1, %bm1 : tensor<64x128xf32>
%exp1 = math.exp2 %dx1 : tensor<64x128xf32>
%sum1 = frisk.reduce_tensor %exp1 {kind="sum",dim=1:i64,frisk.execution_threads=128:i64} : tensor<64x128xf32> -> tensor<64xf32>
%p1 = arith.truncf %exp1 : tensor<64x128xf32> to tensor<64x128xf16>
%newL1 = arith.addf %lscaled1, %sum1 : tensor<64xf32>
%out1 = "frisk.mma"(%p1,%svs,%acc1) {m=64:i64,n=64:i64,k=128:i64,frisk.execution_threads=128:i64,policy=#frisk<gemm_warp_policy FullRow>} : (tensor<64x128xf16>,memref<128x64xf16,3>,tensor<64x64xf32>) -> tensor<64x64xf32>
scf.yield %newM1,%newL1,%out1 : tensor<64xf32>,tensor<64xf32>,tensor<64x64xf32>
}
%ones = arith.constant dense<1.0> : tensor<64xf32>
%inv = arith.divf %ones, %lfinal : tensor<64xf32>
%denom3 = linalg.broadcast ins(%inv : tensor<64xf32>) outs(%emptyO : tensor<64x64xf32>) dimensions = [1]
%out = arith.mulf %ofinal, %denom3 : tensor<64x64xf32>
frisk.tile_store %out, %gO : tensor<64x64xf32>, memref<64x64xf32,1>
frisk.end
}) : () -> ()
frisk.end
}) : () -> ()
}

