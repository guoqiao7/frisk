from pathlib import Path
import sys,os,re,hashlib,ctypes as ct,traceback
from timing import *
D=Path(__file__).parent;A=Path('/data0/baopeihua/frisk-anchor-traffic-1FVmcC')
from native_gemm_execution import DenseGemm,compile_dense_gemm
from gemm_accumulator_slices import read_layouts
def cell(op,m,n,k):return f'{op}_m{m}n{n}k{k}'
def prep(c):
 p=A/'images'/c;d=D/'gem'/c;d.mkdir(parents=True,exist_ok=True);k=int(c.split('k')[-1]);src=(A/'solved'/c/'input.mlir').read_text()
 archive=[q for q in sorted(p.iterdir()) if q.is_dir() and ((q.name.startswith('F') and re.fullmatch('F[12][12][ci]',q.name)) or q.name.startswith('base-')) and (q/'info.json').is_file()]
 for grid in (32,132):
  arms={q.name:str(q) for q in archive};static='F-static';q=d/str(grid);q.mkdir(exist_ok=True)
  prog=DenseGemm.from_open_layout(src,k,grid_ctas=grid,sm_count=114)
  im,meta=compile_dense_gemm(prog);(q/'kernel.cubin').write_bytes(im.asm['cubin']);(q/'solved.mlir').write_text(prog.layout_ir)
  info=dict(smem=meta['dynamic_shared_bytes'],symbol=meta['symbol'],width=meta['resident_atoms'],delivery=meta['delivery'],traffic=meta['slice_traffic']);dump(q/'info.json',info);arms[static]=str(q)
  dump(q/'manifest.json',dict(arms=arms,static=static))
 print('ready',c,flush=True)
class Module:
 def __init__(self,api,p,info):
  self.api=api;self.mod=ct.c_void_p();self.fn=ct.c_void_p();self.shared=info['smem']
  def ok(x):assert x==0,(p,x)
  ok(api.cuModuleLoad(ct.byref(self.mod),str(p).encode()));ok(api.cuModuleGetFunction(ct.byref(self.fn),self.mod,info['symbol'].encode()))
  if self.shared:ok(api.cuFuncSetAttribute(self.fn,8,self.shared))
 def fire(self,grid,stream,args):
  x=self.api.cuLaunchKernel(self.fn,grid,1,1,256,1,1,self.shared,ct.c_void_p(stream),args,None);assert x==0,x
def bench(c):
 import torch
 op=c.startswith('fan');m,n,k=map(int,re.search(r'm(\d+)n(\d+)k(\d+)',c).groups())
 api=ct.CDLL('libcuda.so.1')
 for grid in (32,132):
  q=D/'gem'/c/str(grid);man=read(q/'manifest.json');torch.manual_seed(3932+grid);a=torch.randint(-2,3,(grid,m,k),device='cuda').half();b=torch.randint(-2,3,(grid,k,n),device='cuda').half();out=torch.empty(grid,m,n,device='cuda');red=torch.empty(grid,n,device='cuda');ref=a.double()@b.double()
  pointers=[ct.c_uint64(o.data_ptr()) for o in (a,b,out,red)]+[ct.c_uint64(0),ct.c_uint64(0)];args=(ct.c_void_p*len(pointers))(*(ct.addressof(v) for v in pointers));gs={};mods={};ids={};exc={}
  for arm,name in man['arms'].items():
   p=Path(name);i=read(p/'info.json')
   if i['smem']>torch.cuda.get_device_properties(0).shared_memory_per_block_optin:exc[arm]=i['smem'];continue
   z=p/'kernel.cubin';h=hashlib.sha256(z.read_bytes()).hexdigest();ids[arm]=h
   if h in gs:continue
   obj=Module(api,z,i);mods[h]=obj;out.fill_(float('nan'));red.fill_(float('nan'));obj.fire(grid,torch.cuda.current_stream().cuda_stream,args)
   assert torch.equal(out.double(),ref),(arm,c,grid,'C')
   if op:assert torch.equal(red.double(),ref.sum(1)),(arm,c,grid,'R')
   cg=torch.cuda.CUDAGraph()
   with torch.cuda.graph(cg):
    for _ in range(6):obj.fire(grid,torch.cuda.current_stream().cuda_stream,args)
   gs[h]=cg
  pools={e:list(dict.fromkeys(h for a,h in ids.items() if a.startswith(prefix))) for e,prefix in [('F','F'),('T','base-triton'),('L','base-tilelang')]}
  z=paired(gs,pools,ids['F-static'],c+str(grid));z.update(kind='native GEMM',op='GEMM+column sum' if op else 'GEMM',shape=f'{m}x{n}x{k}',grid=grid,arms=ids,excluded=exc,frisk=read(q/'info.json'))
  dump(D/'data'/f'gem-{c}-g{grid}.json',z);gs.clear();del cg;torch.cuda.synchronize()
  for mo in mods.values():assert api.cuModuleUnload(mo.mod)==0
 print('timed',c,flush=True)
if __name__=='__main__':
 fn=prep if sys.argv[1]=='prep' else bench
 for c in sys.argv[2:]:
  try:fn(c)
  except Exception:
   print(c,traceback.format_exc(),flush=True);(D/'logs'/(c+'-'+sys.argv[1]+'.error')).write_text(traceback.format_exc())

