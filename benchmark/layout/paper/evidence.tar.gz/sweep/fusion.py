from pathlib import Path
import os,re,sys,subprocess,hashlib,traceback,ctypes as ct
from timing import *
from gemrun import Module
import torch
D=Path(__file__).resolve().parent; L=Path('/data0/baopeihua/frisk-loop-layout-U7RAo8')
sys.path.insert(0,str(L/'gem'))
from decode import decode
def run(family,c):
 dual=family=='reglu';t=L/family;m,n,k=map(int,re.search(r'm(\d+)n(\d+)k(\d+)',c).groups())
 maps=read(t/('plans-all.json' if dual else 'plans-low.json'))[c];manifest=read(t/('images.json' if dual else 'images-low.json'))
 src=(Path('/data0/baopeihua/frisk-layout-thesis-dpew4p/dual/inputs') if dual else t/'inputs')/(c+'-open.mlir')
 loc=D/'fusion'/(family+'-'+c);loc.mkdir(parents=True,exist_ok=True);dst=loc/'solved.mlir'
 flag='--frisk-protected-store-layout=anchor-solver=integer integer-native-stripes=true integer-reduction-communication=true'
 subprocess.run([os.environ['FRISK_OPT'],src,flag,'-verify-each','-o',dst],check=True)
 lines=dst.read_text().splitlines();mma=[l for l in lines if ' = frisk.mma ' in l];red=next(l for l in lines if ' = frisk.reduce_tensor ' in l);st=[l for l in lines if 'frisk.tile_store ' in l]
 enc=lambda l:hashlib.sha256(np.asarray(decode(l.rsplit('#frisk.distributed<',1)[1]),dtype='<i4').tobytes()).hexdigest()
 choice=dict(acc=enc(mma[0]),col=enc(red),matrix_store=enc(st[0]),col_store=enc(st[-1]))
 if dual:choice.update(up=enc(mma[1]),joint=enc(next(l for l in lines if ' = arith.mulf ' in l)))
 else:assert enc(red.split(' -> ')[0])==choice['acc']
 elig=set(re.findall(r'eligible = true, grid = array<i64: (\d+, \d+)>',dst.read_text().split('coefficient_variables')[0]))
 matches=[a for a,v in maps.items() if v==choice];assert matches,(c,choice)
 pref=next((a for a in matches if a.startswith('frisk')),matches[0]);grid=64
 torch.manual_seed(8301);a=torch.randint(-2,3,(grid,m,k),device='cuda').half();b=torch.randint(-2,3,((grid,2,k,n) if dual else (grid,k,n)),device='cuda').half()
 ref=((a.double()@b[:,0].double()).relu()*(a.double()@b[:,1].double()) if dual else a.double()@b.double())
 dim=2 if c.startswith('row') else 1;expected=ref.amax(dim);out=torch.empty_like(ref,dtype=torch.float32);rr=torch.empty_like(expected,dtype=torch.float32)
 pointers=[ct.c_uint64(o.data_ptr()) for o in (a,b,out,rr)]+[ct.c_uint64(0),ct.c_uint64(0)]
 args=(ct.c_void_p*len(pointers))(*(ct.addressof(v) for v in pointers));api=ct.CDLL('libcuda.so.1');imgs={};gs={};ids={}
 for arm in maps:
  z=t/'images'/(c+'-'+arm)/'kernel.cubin';h=hashlib.sha256(z.read_bytes()).hexdigest();assert h==manifest[c+'-'+arm]['cubin'];ids[arm]=h
  if h in gs:continue
  mod=Module(api,z,dict(smem=65536,symbol='replay'));imgs[h]=mod
  out.fill_(float('nan'));rr.fill_(float('nan'));mod.fire(grid,torch.cuda.current_stream().cuda_stream,args)
  assert torch.equal(out.double(),ref) and torch.equal(rr.double(),expected),(family,c,arm)
  cg=torch.cuda.CUDAGraph()
  with torch.cuda.graph(cg):
   for _ in range(6):mod.fire(grid,torch.cuda.current_stream().cuda_stream,args)
  gs[h]=cg
 pool=[ids[pref]]+[ids[a] for a,e in [('g12L','1, 2'),('g21L','2, 1')] if a in ids and e in elig]
 suffix='' if dual else 'L';z=paired(gs,dict(F=list(dict.fromkeys(pool)),T=[ids['triton'+suffix]],L=[ids['tilelang'+suffix]]),ids[pref],family+c)
 z.update(kind='layout',op=(('ReGLU+row max' if dim==2 else 'ReGLU+column max') if dual else 'GEMM+column max'),shape=f'{m}x{n}x{k}',grid=grid,arms=ids,eligible=sorted(elig),current_matches=matches)
 dump(D/'data'/f'fusion-{family}-{c}.json',z);gs.clear();del cg;torch.cuda.synchronize()
 for mo in imgs.values():assert api.cuModuleUnload(mo.mod)==0
 print('timed',family,c,flush=True)
if __name__=='__main__':
 for family,cs in read(D/'fusion-design.json')['domain'].items():
  for c in cs:
   try:run(family,c)
   except Exception:print(family,c,traceback.format_exc(),flush=True)

