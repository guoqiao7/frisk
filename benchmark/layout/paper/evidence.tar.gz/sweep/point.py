import sys,os,json,hashlib,traceback
from pathlib import Path
from timing import paired,read,dump
R=Path(__file__).parent;V=Path('/data0/baopeihua/frisk-vector-access-o2wm17');sys.path.insert(0,str(V))
import graphs as gg
from native_cal import compile_pkt,torch
from native_pointwise_selection import compile_pointwise_access
from elftext import sections
frozen={r['key']:r for r in read('/data0/baopeihua/frisk-pointwise-integer-L7Rih8/frozen.json')['rows']}
def run(c):
 m,n,ds,add=c;tag=gg.key(c);p=R/'point'/tag;p.mkdir(parents=True,exist_ok=True)
 tiles=4194304//(m*n);x=torch.arange(tiles*m*n,device='cuda',dtype=torch.int32).remainder_(1999).float();buf=[x]+[torch.empty_like(x) for _ in range(3)]
 v=x.view(tiles,m,n);v=v+1 if add else v;ref=[(v if k=='R' else v.transpose(1,2)).contiguous().flatten() for k in ds[1:]]
 gs={};held=[];ids={}
 def prep(pkt,d):
  im=compile_pkt(pkt,c,d/'kernel.ttgir');im._init_handles();held.append(im);sec=sections(im.asm['cubin']);h=hashlib.sha256(b''.join(v for k,v in sorted(sec.items()) if k.startswith(('.text','.nv.constant')))+str((im.n_regs,im.n_spills,im.metadata.shared)).encode()).hexdigest();ids[d.name]=h
  if h not in gs:
   for out in buf[1:]:out.fill_(-777)
   im[(tiles,1,1)](*buf);assert all(torch.equal(y,z) for y,z in zip(buf[1:],ref)) and all((a==-777).all() for a in buf[1+len(ref):])
   cg=torch.cuda.CUDAGraph()
   with torch.cuda.graph(cg):
    for _ in range(6):im[(tiles,1,1)](*buf)
   gs[h]=cg
  return im,gs[h].replay
 src=p/'input.mlir';src.write_text(gg.make(c));im,pkt,sel=compile_pointwise_access(src,os.environ['FRISK_OPT'],p,prep)
 for name,srcname in [('T','triton'),('L','tile')]:
  pol=frozen[tag]['policies'][srcname];dest=p/name;dest.mkdir(exist_ok=True);pkt=gg.packet(c,dest/'fixed',gg.make(c,pol));assert gg.observed(c,pkt)==pol;prep(pkt,dest)
 z=paired(gs,{'F':list(dict.fromkeys(ids[a] for a in ('scalar','native'))),'T':[ids['T']],'L':[ids['L']]},ids[sel['winner']],tag)
 z.update(kind='layout',op={'RR':'Copy','RC':'Transpose','RRC':'Add, two stores'}[ds],shape=f'{m}x{n}',grid=tiles,arms=ids,mode=sel['winner'],errors={});dump(R/'data'/('point-'+tag+'.json'),z)
 print('timed',tag,flush=True)
if __name__=='__main__':
 for c in read(R/'point-design.json'):
  if len(sys.argv)>1 and gg.key(c) not in sys.argv[1:]:continue
  try:run(c)
  except Exception:
   (R/'logs'/('failed-point-'+gg.key(c))).write_text(traceback.format_exc());print(c,traceback.format_exc(),flush=True)

