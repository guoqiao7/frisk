from pathlib import Path
import os,sys,re,traceback,hashlib,shutil
from timing import read,dump,paired
R=Path(__file__).resolve().parent;cfg=read(R/'design.json');F=Path('/data0/baopeihua/frisk-fa-shape-sweep-OI7QjD');V=Path('/data0/baopeihua/frisk-gqa-resident-w7a5Iz');J=Path('/data0/baopeihua/frisk-fa-joint-cIk02C')
def run(kind,n,h,kv,c):
 p=R/'fa'/'-'.join(map(str,(kind,n,h,kv,c)));assert (p/'static.json').is_file();skip={};fs={};sources={}
 if kind=='mha128':
  sys.path.insert(0,str(J));import run_sweep as w
  torch=w.torch;r=(n,n,h,c);ref_src=w.oldbench.make_inputs(r,34319+n+h);q,k,v,ref=ref_src
  back=torch.full((q.numel()+32768,),-37.,device='cuda',dtype=q.dtype);buf=back[16384-64:-(16384-64)];ts=(q,k,v,buf[64:-64].view_as(q))
  factories,skip=w.factories(r,ts)
  blocked=read(J/'quarantine.json').get(w.key(r),{});skip.update(blocked)
  for name,mk in factories.items():
   if name in blocked:continue
   try:fs[name]=mk()
   except Exception as e:skip[name]=repr(e)
  so=next(p.rglob('fa3.so'));current=w.bm.library(so,True);fs['F/static']=lambda:current(ts)
  graph=w.bm.graph
 elif kind=='mha64':
  sys.path.insert(0,str(F/'l64'));import paired as w
  import bench as b
  torch=w.torch;r=(n,h,c);orig=F/'l64'/'cases'/w.tag(r)
  if not orig.exists():orig=Path(os.environ['KVRANK'])/'cases'/w.tag(r)
  assert orig.is_dir(),orig
  q,k,v,ref=w.inputs(n,64,h,c,34319+n+h);back=torch.full((ref.numel()+32768,),-37.,device='cuda',dtype=ref.dtype);buf=back[16384-64:-(16384-64)];ts=q,k,v,buf[64:-64].view_as(ref)
  extp=p/'ref'/'external';extp.mkdir(exist_ok=True,parents=True)
  for f in (orig/'external').iterdir():
   if f.suffix in ('.so','.error') and not (extp/f.name).exists():(extp/f.name).symlink_to(f.resolve())
  b.path=lambda _:extp.parent
  external,libs=b.ext(r,ts);fs.update(external)
  w.path=lambda _:orig;b.path=lambda _:orig
  for a in w.arms(r,True):
   fs['F/'+a]=b.native(r,a,ts);sources['F/'+a]=str(orig/a/'kernel.cubin')
  b.path=lambda _:p.parent;fs['F/static']=b.native(r,p.name,ts);sources['F/static']=str(p/'kernel.cubin')
  graph=b.graph
 else:
  sys.path.insert(0,str(V));import final_accept as w
  x=(1,h,kv,n,n,64,64,c);torch=w.torch;ts,ref,buf,back=w.getdata(x)
  extra,_=w.launchers(x,ts,[]);fs.update(extra)
  roots={}
  for a in list(dict.fromkeys(w.plans(x)+w.pairednames(x)+w.sw)):
   loc=w.W/'row'/w.key(x)/a if a in w.sw else w.native(x,a)
   if not (loc/'metadata.json').is_file():loc=w.W/'missing-old'/w.key(x)/a
   if (loc/'metadata.json').is_file():roots[a]=loc
  for a,loc in roots.items():
   w.bm.path=lambda _,loc=loc:loc.parent;fs['F/'+a]=w.bm.native(None,loc.name,ts);sources['F/'+a]=str(loc/'kernel.cubin')
  w.bm.path=lambda _:p.parent;fs['F/static']=w.bm.native(None,p.name,ts);sources['F/static']=str(p/'kernel.cubin')
  graph=w.bm.graph
 torch.backends.cuda.matmul.allow_tf32=False
 gs={};errs={};alias={};byimg={}
 for name in ['F/static']+[z for z in fs if z!='F/static']:
  try:
   policy=name
   if name in sources:
    file=Path(sources[name]);meta=read(file.parent/'metadata.json') if (file.parent/'metadata.json').is_file() else {}
    sig=(hashlib.sha256(file.read_bytes()).hexdigest(),str((meta.get('launch_grid'),meta.get('threads'),meta.get('dynamic_shared_bytes'))))
    if sig in byimg:alias[name]=byimg[sig];continue
   gs[name],errs[name]=graph(fs[name],buf,ref,6)
   assert (back[:16384]==-37).all() and (back[-16384:]==-37).all()
   alias[name]=name
   if name in sources:byimg[sig]=name
  except Exception as e:
   if name=='F/static':raise
   skip[name]=repr(e);back[:16384].fill_(-37.);back[-16384:].fill_(-37.)
 pools={a:list(dict.fromkeys(v for k,v in alias.items() if k.startswith(a))) for a in 'FTL'}
 assert all(pools.values()),(pools,skip)
 z=paired(gs,pools,'F/static',p.name)
 z.update(kind='native FA',op=('GQA' if kind=='gqa64' else 'MHA')+(' causal' if c else ' full')+(' D128' if kind=='mha128' else ' D64'),shape=f'N{n} H{h}/{kv}',grid=None,arms=alias,errors=errs,excluded=skip)
 dump(R/'data'/('fa-'+p.name+'.json'),z);print('timed',p.name,{k:len(v) for k,v in pools.items()},flush=True)
if __name__=='__main__':
 k=sys.argv[1]
 xs=([(n,h,h,c) for n,h in cfg['d64_mha'] for c in cfg['mha_masks']] if k=='mha64' else cfg['d64_gqa'] if k=='gqa64' else [(n,h,h,1) for n,h in cfg['d128_causal']])
 for x in xs:
  if len(sys.argv)>2 and str(x[0]) not in sys.argv[2:]:continue
  try:run(k,*x)
  except Exception:(R/'logs'/('failed-'+k+'-'+'-'.join(map(str,x)))).write_text(traceback.format_exc());print(k,x,traceback.format_exc(),flush=True)

