from pathlib import Path
import os,sys,json,traceback
from concurrent.futures import ThreadPoolExecutor
from attention_pipeline_selection import compile_static_d64_attention,compile_static_gqa_attention
from native_fa3_execution import compile_static_fa3
from timing import dump,read
D=Path(__file__).parent;cfg=read(D/'design.json');opt=os.environ['FRISK_OPT']
def keys():
 return [('mha64',n,h,h,c) for n,h in cfg['d64_mha'] for c in cfg['mha_masks']]+[('gqa64',n,h,g,c) for n,h,g,c in cfg['d64_gqa']]+[('mha128',n,h,h,1) for n,h in cfg['d128_causal']]
def key(x):return '-'.join(map(str,x))
def build(x):
 kind,n,h,g,c=x;p=D/'fa'/key(x);p.mkdir(exist_ok=True)
 try:
  if kind=='mha128':
   ims,z=compile_static_fa3('/data0/baopeihua/frisk-consumer-factorial-F2M8TE/freeze/plan615.json',opt,p,rows=n,heads=h,causal=bool(c),budget=1,tilelang_root='/home/baopeihua/pipeline/tilelang')
   assert len(ims)==1
  else:
   opts=dict(rows=n,heads=h,causal=bool(c),aligned_inputs=True,row_reciprocal=True,softmax_math='base2-ftz')
   if h==g:im,md,z=compile_static_d64_attention(opt,p,**opts)
   else:im,md,z=compile_static_gqa_attention(opt,p,dim=64,kv_heads=g,**opts)
  dump(p/'static.json',z);print('ready',x,flush=True)
 except Exception:(p/'prep.error').write_text(traceback.format_exc());print(x,traceback.format_exc(),flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(4) as ex:list(ex.map(build,keys()))

