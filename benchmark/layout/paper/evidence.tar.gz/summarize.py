from pathlib import Path
import csv,json,hashlib,statistics,collections,sys
import numpy as np
P=Path(__file__).resolve().parent;O=P/'paper';O.mkdir(exist_ok=True)
med=statistics.median
read=lambda p:json.loads(p.read_text())
def table(out,rows):
 with (O/out).open('w',newline='') as f:
  w=csv.DictWriter(f,rows[0],lineterminator='\n');w.writeheader();w.writerows(rows)
rows=[]
def add(study,op,shape,grid,policy,blocks,keys,idn):
 f,fs,t,l=keys
 us=[med(b[k] for b in blocks) for k in keys]
 peer=t if us[2]<=us[3] else l
 ratios=np.array([b[f]/b[peer] for b in blocks])
 seed=int(hashlib.sha256(idn.encode()).hexdigest()[:8],16)
 rng=np.random.default_rng(seed)
 ci=np.percentile(np.median(rng.choice(ratios,(2000,len(ratios)),replace=True),axis=1),[2.5,97.5])
 rows.append(dict(study=study,op=op,shape=shape,grid=grid,policy=policy,frisk_us=round(us[0],4),frisk_screen_pick_us=round(us[1],4),triton_us=round(us[2],4),tilelang_us=round(us[3],4),paired_pct=round(100*(med(ratios)-1),3),ci_low_pct=round(100*(ci[0]-1),3),ci_high_pct=round(100*(ci[1]-1),3),blocks=len(blocks),record=idn))
def main():
 for pat,sz in [('fusion',16),('gem',4),('fa',5),('point',13),('norm',10)]:
  files=sorted((P/'sweep/data').glob(pat+'-*.json'));assert len(files)==sz,(pat,len(files))
  for file in files:
   a=read(file);assert len(a['screen'])==11 and len(a['samples'])==33
   add(a['kind'],a['op'],a['shape'],a['grid'],a.get('mode',''),a['samples'],[a['static'],*[a['picks'][k] for k in 'FTL']],str(file.relative_to(P)))
 for n in (127,256,511,640,1025,1536):
  for c in (0,1):
   files=[P/'fa-fixed/fixed'/f'time-{n}-{c}-{i}.json' for i in (0,1)];s=[read(f) for f in files];assert s[0]['aliases']==s[1]['aliases']
   for w in ('1','4','prefetch-v'):
    k=[s[0]['aliases'][w+'-'+e] for e in ('frisk','frisk','triton','tilelang')]
    add('fixed FA replay','MHA causal D64' if c else 'MHA full D64',f'N{n} H8/8',8*((n+255)//256),w,s[0]['samples']+s[1]['samples'],k,'fa-fixed/fixed/'+f'time-{n}-{c}-{{0,1}}.json')
 c2=P/'c2-replay';img=read(c2/'images.json')
 for mode in ('ss','rs'):
  for op in ('store','row','col'):
   data=[read(c2/f'times-{mode}-{op}-128-{i}.json') for i in (0,1)]
   blocks=[b['us'] for a in data for b in a['blocks']]
   for anchor in ('12','21','open'):
    keys=[img[f'{role}-{mode}-{op}-{anchor}']['cubin'] for role in ('frisk','frisk','triton','tile')]
    add('C2 frozen replay',f'{mode} {op}','128x512x16',128,anchor,blocks,keys,'c2-replay/'+f'times-{mode}-{op}-128-{{0,1}}.json')
 table('threeway.csv',rows)
 fixed_rows=list(csv.DictReader((P/'factorial/corrected-selection.csv').open()))
 factorial=[]
 for row in csv.DictReader((P/'factorial/four-arms.csv').open()):
  graph=row['graph'];grid=row['ctas'];arm=row['image'];case=graph+'_m256n512k256'
  blocks=[b for i in (1,2) for b in read(P/'factorial/results'/f'pairs{i}'/(case+'.json'))['samples'][grid]]
  # Locked historical reference arm and current median of independent replays.
  match=[r for r in fixed_rows if (r['graph'],r['B'],r['ctas'],r['anchor_policy'],r['delivery_policy'])==(graph,row['b_reuse'],grid,row['anchor_policy'],row['delivery_policy'])]
  assert len(match)==1 and match[0]['before']==arm
  repaired=match[0]['after']
  identity=read(P/'factorial/image-identity.json')[case+'/'+repaired]
  assert identity['corrected']==identity['measured']
  choices=read(P/'factorial/selections.json');anchors={'12','21'} if row['anchor_policy']=='open' else {'21'}
  allowed=set()
  for key,rec in choices.items():
   g,b,a,d=key.split('-')
   if (g,b)==(graph,row['b_reuse']) and a in anchors and d!='auto' and (row['delivery_policy']=='auto' or d=='dd'):
    allowed.add(rec['image'])
  other=min(sorted(allowed),key=lambda arm:med(b[arm] for b in blocks))
  factorial.append({**{k:row[k] for k in ['graph','b_reuse','ctas','anchor_policy','delivery_policy','anchor','C_route','R_route','image','cubin']},'corrected_arm':repaired,'corrected_us':round(med(b[repaired] for b in blocks),4),'gpu0_us':round(med(b[arm] for b in blocks),4),'gpu0_best_arm':other,'gpu0_best_us':round(med(b[other] for b in blocks),4),'blocks':len(blocks)})
 table('consumer-ablation.csv',factorial)
 norm=[]
 for q in sorted((P/'norm/raw').glob('*.json')):
  a=read(q);samples=a['samples'];sel=a['aliases'][a['selected']];best=min(set(a['aliases'].values()),key=lambda k:med(r[k] for r in samples))
  norm.append(dict(grid=a['grid'],inputs=a['nx'],outputs=a['ny'],selection=a['selected'],selected_us=round(med(r[sel] for r in samples),4),pool_best_us=round(med(r[best] for r in samples),4),blocks=len(samples)))
 assert len(norm)==8
 table('normalization-reuse.csv',norm)
 anchor=[]
 cfg=read(P/'anchor/design.json')
 for case in sorted((P/'anchor/images').iterdir()):
  g,m,n,k=case.name.split('-'); a=read(case/'choices.json'); blocks=read(case/'paired.json')
  for grid,samples in blocks.items():
   times={key:med(r[key] for r in samples) for key in a['domain']};winner=min(times,key=times.get)
   old=a['before'];current=a['grids'][grid]['after']
   anchor.append(dict(graph=g,shape=f'{m}x{n}x{k}',grid=grid,domain='|'.join(sorted(times)),split='focus' if list(map(int,(m,n,k)))==cfg['focus'] else 'previous_holdout',old=old,selected=current,fastest=winner,selected_us=round(times[current],4),fastest_us=round(times[winner],4),loss_pct=round(100*(times[current]/times[winner]-1),4),blocks=len(samples)))
 assert len(anchor)==42
 table('native-anchor.csv',anchor)
 print('threeway',len(rows),collections.Counter(r['study'] for r in rows),'factorial',len(factorial),'reuse',len(norm))
if __name__=='__main__':main()
