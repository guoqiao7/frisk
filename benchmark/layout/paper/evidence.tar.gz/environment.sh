source /data0/baopeihua/frisk-twoq-kv64-ewXyMu/run_env.sh
export CUDA_VISIBLE_DEVICES=GPU-7bafb1de-da7b-3bf6-e8cd-2369e0c92767
export FRISK_OPT=/home/baopeihua/frisk/build-m6-release/bin/frisk-opt
export PYTHONPATH="/home/baopeihua/frisk/benchmark/layout/execution:/home/baopeihua/tilelang:/home/baopeihua/tilelang/3rdparty/tvm/python:${PYTHONPATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
