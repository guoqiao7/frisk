"""Qualify fixed GEMM cubins using only the CUDA Driver and Python stdlib."""

import argparse
from contextlib import ExitStack, contextmanager
import ctypes as ct
from hashlib import sha256
import importlib.util
import json
from math import isfinite
import os
from pathlib import Path
from random import Random
from statistics import median
import struct
import subprocess
import sys


MODES = ('serial-one', 'serial-two', 'prefetch')
FRAMEWORKS = ('triton', 'tilelang', 'tvm', 'torch')
BLOCK = (128, 1, 1)
OFFSETS = ((0, 0, 0), (16, 32, 48), (48, 16, 32))
GUARD = 512
CANARY = b'\xd3'
NAN = struct.pack('<f', float('nan'))
P, U, I, Z, D = ct.c_void_p, ct.c_uint, ct.c_int, ct.c_size_t, ct.c_uint64
REF = ct.byref
DECLARATIONS = {
    'cuInit': [U],
    'cuDeviceGetCount': [ct.POINTER(I)],
    'cuDeviceGet': [ct.POINTER(I), I],
    'cuDeviceGetUuid_v2': [P, I],
    'cuDeviceGetAttribute': [ct.POINTER(I), I, I],
    'cuCtxCreate_v2': [ct.POINTER(P), U, I],
    'cuCtxDestroy_v2': [P],
    'cuCtxSynchronize': [],
    'cuStreamCreate': [ct.POINTER(P), U],
    'cuStreamSynchronize': [P],
    'cuStreamDestroy_v2': [P],
    'cuMemAlloc_v2': [ct.POINTER(D), Z],
    'cuMemFree_v2': [D],
    'cuMemcpyHtoD_v2': [D, P, Z],
    'cuMemcpyDtoH_v2': [P, D, Z],
    'cuModuleLoadData': [ct.POINTER(P), P],
    'cuModuleGetFunction': [ct.POINTER(P), P, ct.c_char_p],
    'cuModuleUnload': [P],
    'cuFuncGetParamInfo': [P, Z, ct.POINTER(Z), ct.POINTER(Z)],
    'cuFuncGetAttribute': [ct.POINTER(I), I, P],
    'cuFuncSetAttribute': [P, I, I],
    'cuOccupancyMaxActiveBlocksPerMultiprocessor': [ct.POINTER(I), P, I, Z],
    'cuLaunchKernel': [P] + [U] * 7 + [P, ct.POINTER(P), P],
    'cuStreamBeginCapture_v2': [P, I],
    'cuStreamEndCapture': [P, ct.POINTER(P)],
    'cuGraphGetNodes': [P, P, ct.POINTER(Z)],
    'cuGraphInstantiateWithFlags': [ct.POINTER(P), P, D],
    'cuGraphLaunch': [P, P],
    'cuGraphExecDestroy': [P],
    'cuGraphDestroy': [P],
    'cuEventCreate': [ct.POINTER(P), U],
    'cuEventRecord': [P, P],
    'cuEventSynchronize': [P],
    'cuEventElapsedTime': [ct.POINTER(ct.c_float), P, P],
    'cuEventDestroy_v2': [P],
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return sha256(data).hexdigest()


def artifact(path, digest):
    path = Path(path)
    require(path.is_absolute(), f'expected absolute artifact path, got {path}')
    content = path.read_bytes()
    require(sha(content) == digest, f'changed registered artifact {path}')
    return content


def _compact(row):
    batch, k = row['batch'], row['k']
    require(type(batch) is int and batch > 0 and type(k) is int and k > 0 and k % 16 == 0,
            'invalid fixed GEMM dimensions')
    facts = json.loads(artifact(row['loop']['facts'], row['loop']['facts_sha256']))
    from gemm_pipeline_plan import checked_facts

    checked_facts(facts)
    m, n = (facts['shape'][key] for key in ('m', 'n'))
    require(facts['shape'] == row['spec'] == dict(batch=batch, k=k, m=m, n=n),
            'incompatible compact GEMM iteration or shape')
    for index, (name, rows, width) in enumerate((('lhs', m, k), ('rhs', n, k), ('output', m, n))):
        root = facts[name]
        require((root['arg_index'], root['row_stride'], root['batch_stride'], root['alignment'])
                == (index, width, rows * width, 16), 'qualification expects the frozen compact ABI')
    require(facts['rhs']['transposed'] is True, 'qualification expects B already transposed')
    return facts['lower'], facts['upper']


def load_manifest(path, selected, modes):
    content = path.read_bytes()
    cases = {}
    for row in json.loads(content)['programs']:
        key = row['batch'], row['k']
        mode, image = row['mode'], row['image']
        require(mode in MODES, f'unknown GEMM mode {mode}')
        if (selected and key not in selected) or mode not in modes:
            continue
        case = cases.setdefault(key, {})
        require(mode not in case, f'duplicate GEMM mode {mode}')
        require(image['entry'] == 'frisk_execution' and image['grid'] == [key[0], 1, 1]
                and tuple(image['block']) == BLOCK and image['dynamic_shared_bytes'] == 0
                and image['alignment_bytes'] == 16, 'GEMM launch ABI changed')
        binary = artifact(image['cubin'], image['cubin_sha256'])
        require(binary[:4] == b'\x7fELF', 'expected ELF cubin')
        case[mode] = dict(row=row, binary=binary, bounds=_compact(row))
    require(cases and all(set(case) == set(modes) for case in cases.values()),
            'need all requested GEMM modes per shape')
    require(not selected or set(cases) == selected, 'missing requested GEMM shapes')
    return cases, sha(content)


def _smi(*args):
    return subprocess.check_output(['nvidia-smi', *args], text=True, timeout=10).strip()


def gpu_state(uuid):
    info = _smi('-i', uuid, '--query-gpu=index,uuid,name,driver_version', '--format=csv,noheader')
    index, found, model, driver = (field.strip() for field in info.split(','))
    require(found == uuid and 'H100' in model, 'expected the scheduled H100')
    running = _smi('--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits')
    pids = set()
    for line in running.splitlines():
        device, pid = map(str.strip, line.split(',', 1))
        if device == uuid:
            pids.add(int(pid))
    require(not (pids - {os.getpid()}), f'scheduled GPU has foreign contexts {pids - {os.getpid()}}')
    return dict(index=int(index), uuid=uuid, model=model, driver=driver, current_process_active=bool(pids))


class Driver:
    def __init__(self, uuid, stack):
        self.cuda = ct.CDLL('libcuda.so.1')
        for name, signature in DECLARATIONS.items():
            function = getattr(self.cuda, name)
            function.argtypes, function.restype = signature, I
        self.call('cuInit', 0)
        count = self.value('cuDeviceGetCount', I)
        require(count == 1, 'expose exactly one GPU via its UUID')
        device = self.value('cuDeviceGet', I, 0)
        raw = (ct.c_ubyte * 16)()
        self.call('cuDeviceGetUuid_v2', REF(raw), device)
        require(bytes(raw).hex() == uuid[4:].replace('-', '').lower(), 'CUDA device UUID changed')
        capability = tuple(self.value('cuDeviceGetAttribute', I, attribute, device)
                           for attribute in (75, 76))
        require(capability == (9, 0), 'expected compute capability 9.0')
        context = self.value('cuCtxCreate_v2', P, 0, device)
        stack.callback(self.call, 'cuCtxDestroy_v2', context)
        self.stream = self.value('cuStreamCreate', P, 1)
        stack.callback(self.call, 'cuStreamDestroy_v2', self.stream)

    def call(self, name, *args):
        status = getattr(self.cuda, name)(*args)
        if status:
            raise RuntimeError(f'{name} returned CUDA status {status}')

    def value(self, name, output, *args):
        result = output()
        self.call(name, REF(result), *args)
        return result.value

    def synchronize(self):
        self.call('cuStreamSynchronize', self.stream)

    def allocate(self, stack, size):
        pointer = self.value('cuMemAlloc_v2', D, size)
        stack.callback(self.call, 'cuMemFree_v2', pointer)
        return pointer

    def copy_to(self, pointer, data):
        self.call('cuMemcpyHtoD_v2', pointer, ct.c_char_p(data), len(data))

    def synchronize_uploads(self):
        # Pageable HtoD may return after staging. The nonblocking compute
        # stream does not implicitly wait for the default-stream transfers.
        self.call('cuCtxSynchronize')

    def copy_from(self, pointer, size):
        data = ct.create_string_buffer(size)
        self.call('cuMemcpyDtoH_v2', data, pointer, size)
        return data.raw


class Image:
    def __init__(self, driver, checked, stack, *, exact):
        self.driver = driver
        launch = checked['row']['image']
        self.grid = launch['grid']
        self.block = tuple(launch['block'])
        self.dynamic_shared_bytes = checked.get('dynamic_shared_bytes', 0)
        require(type(self.dynamic_shared_bytes) is int and self.dynamic_shared_bytes >= 0
                and launch.get('dynamic_shared_bytes', 0) == self.dynamic_shared_bytes,
                'GPU image lacks a checked dynamic Shared reservation')
        require(self.block in (BLOCK, (2 * BLOCK[0], 1, 1)), 'unsupported checked CTA shape')
        module = driver.value('cuModuleLoadData', P, ct.c_char_p(checked['binary']))
        stack.callback(driver.call, 'cuModuleUnload', module)
        self.function = driver.value('cuModuleGetFunction', P, module, b'frisk_execution')
        for index in range(5):
            offset, width = Z(), Z()
            driver.call('cuFuncGetParamInfo', self.function, index, REF(offset), REF(width))
            require((offset.value, width.value) == (8 * index, 8), 'GPU image changed its pointer ABI')
        if not exact:
            require(driver.cuda.cuFuncGetParamInfo(self.function, 5, REF(Z()), REF(Z())) == 1,
                    'GPU image has an unexpected extra argument')
        attributes = dict(max_threads_per_block=0, shared_bytes=1, local_bytes_per_thread=3,
                          registers_per_thread=4)
        self.resources = {key: driver.value('cuFuncGetAttribute', I, code, self.function)
                          for key, code in attributes.items()}
        if self.dynamic_shared_bytes:
            require(self.resources['shared_bytes'] == checked.get('static_shared_bytes'),
                    'GPU image changed its checked static Shared allocation')
            max_dynamic_shared = 8  # CU_FUNC_ATTRIBUTE_MAX_DYNAMIC_SHARED_SIZE_BYTES
            driver.call('cuFuncSetAttribute', self.function, max_dynamic_shared, self.dynamic_shared_bytes)
            require(driver.value('cuFuncGetAttribute', I, max_dynamic_shared, self.function)
                    >= self.dynamic_shared_bytes, 'GPU did not opt into the checked dynamic Shared size')
            self.resources.update(dynamic_shared_bytes=self.dynamic_shared_bytes,
                                  physical_shared_bytes=self.resources['shared_bytes'] + self.dynamic_shared_bytes)
        self.resources['ctas_per_sm'] = driver.value('cuOccupancyMaxActiveBlocksPerMultiprocessor', I,
                                                     self.function, self.block[0], self.dynamic_shared_bytes)
        require(self.resources['max_threads_per_block'] >= self.block[0] and self.resources['ctas_per_sm'] > 0,
                'GPU resources violate the frozen launch contract')

    def launch(self, params):
        self.driver.call('cuLaunchKernel', self.function, *self.grid, *self.block, self.dynamic_shared_bytes,
                         self.driver.stream, params, None)


def fixture(batch, k, bounds, pattern):
    lower, upper = bounds
    banks = min(batch, 5)
    left, right, reference = [], [], []
    for bank in range(banks):
        rng = Random(1729 + 13 * k + bank)
        if pattern == 'random':
            a, b = ([rng.randrange(-4096, 4097) / 4096 for _ in range(64 * k)] for _ in range(2))
        elif pattern == 'signed':
            a, b = ([rng.randrange(-3, 4) for _ in range(64 * k)] for _ in range(2))
        elif pattern == 'tile-signature':
            a = [(row % 7 + 1) * (col // 16 + 1) if col % 16 == (row + bank) % 16 else 0
                 for row in range(64) for col in range(k)]
            b = [row % 9 - 4 if col % 16 == (3 * row + 2 * bank) % 16 else 0
                 for row in range(64) for col in range(k)]
        else:
            a, b = [0] * (64 * k), [rng.randrange(-3, 4) for _ in range(64 * k)]
        left.append(struct.pack(f'<{64*k}e', *a))
        right.append(struct.pack(f'<{64*k}e', *b))
        a, b = (struct.unpack(f'<{64*k}e', payload[-1]) for payload in (left, right))
        a_rows, b_rows = ([values[i*k+lower:i*k+upper] for i in range(64)] for values in (a, b))
        reference.append(tuple(sum(x * y for x, y in zip(lhs, rhs))
                               for lhs in a_rows for rhs in b_rows))
    return (b''.join(left[i % banks] for i in range(batch)),
            b''.join(right[i % banks] for i in range(batch)),
            tuple(value for i in range(batch) for value in reference[i % banks]))


class Buffers:
    def __init__(self, driver, stack, inputs, output_count, offsets, *, exact):
        self.driver = driver
        self.starts = (0, 0, 0) if exact else tuple(GUARD + offset for offset in offsets)
        self.ends = tuple(start + size for start, size in
                          zip(self.starts, (len(inputs[0]), len(inputs[1]), 4 * output_count)))
        self.guard = b'' if exact else CANARY * GUARD
        self.host = tuple(CANARY * start + data + self.guard for start, data in zip(self.starts, inputs))
        self.addresses = [driver.allocate(stack, end + len(self.guard)) for end in self.ends]
        for pointer, data in zip(self.addresses, self.host):
            driver.copy_to(pointer, data)
        arguments = [pointer + start for pointer, start in zip(self.addresses, self.starts)]
        require(all(pointer % 16 == 0 for pointer in arguments), 'test buffer changed pointer alignment')
        self.args = tuple(D(value) for value in (*arguments, 0, 0))
        self.params = (P * 5)(*(ct.cast(REF(value), P) for value in self.args))

    def reset(self):
        start, end = self.starts[-1], self.ends[-1]
        self.driver.copy_to(self.addresses[-1], CANARY * start + NAN * ((end - start) // 4) + self.guard)

    def read(self):
        for pointer, expected in zip(self.addresses, self.host):
            require(self.driver.copy_from(pointer, len(expected)) == expected,
                    'GEMM wrote into input or its redzone')
        start, end = self.starts[-1], self.ends[-1]
        raw = self.driver.copy_from(self.addresses[-1], end + len(self.guard))
        require(raw[:start] == CANARY * start and raw[end:] == self.guard, 'GEMM wrote into output redzone')
        return raw[start:end]


def compare_output(bits, reference, pattern):
    limit = 4e-5 if pattern == 'random' else 0
    worst = 0.
    for (actual,), expected in zip(struct.iter_unpack('<f', bits), reference, strict=True):
        error = abs(actual - expected)
        require(isfinite(actual) and error <= limit * (1 + abs(expected)),
                f'GEMM disagrees with host reference, actual={actual}, expected={expected}')
        worst = max(worst, error)
    return worst


@contextmanager
def capture(driver, image, params, launches):
    with ExitStack() as stack:
        graph = P()
        driver.call('cuStreamBeginCapture_v2', driver.stream, 0)
        try:
            for _ in range(launches):
                image.launch(params)
        finally:
            status = driver.cuda.cuStreamEndCapture(driver.stream, REF(graph))
            if graph.value:
                stack.callback(driver.call, 'cuGraphDestroy', graph)
        require(status == 0 and graph.value, f'CUDA graph capture failed with status {status}')
        count = Z()
        driver.call('cuGraphGetNodes', graph, None, REF(count))
        require(count.value == launches, 'CUDA graph lost GEMM launches')
        executable = driver.value('cuGraphInstantiateWithFlags', P, graph, 0)
        stack.callback(driver.call, 'cuGraphExecDestroy', executable)
        yield executable


def timing(driver, loaded, buffers, pairs):
    launches, replays = 64, 4
    with ExitStack() as stack:
        graphs = {label: stack.enter_context(capture(driver, image, buffers.params, launches))
                  for label, image in loaded.items()}
        events = [driver.value('cuEventCreate', P, 0) for _ in range(2)]
        for event in events:
            stack.callback(driver.call, 'cuEventDestroy_v2', event)
        start, stop = events
        for graph in graphs.values():
            driver.call('cuGraphLaunch', graph, driver.stream)
        driver.synchronize()

        def measure(graph):
            driver.call('cuEventRecord', start, driver.stream)
            for _ in range(replays):
                driver.call('cuGraphLaunch', graph, driver.stream)
            driver.call('cuEventRecord', stop, driver.stream)
            driver.call('cuEventSynchronize', stop)
            elapsed = ct.c_float()
            driver.call('cuEventElapsedTime', REF(elapsed), start, stop)
            require(elapsed.value > 0, 'CUDA events measured an empty timing interval')
            return elapsed.value * 1000 / (launches * replays)

        by_mode = {}
        for mode in (mode for mode in MODES if ('standalone', mode) in loaded):
            frozen, standalone = ('golden', mode), ('standalone', mode)
            samples = []
            for i in range(pairs):
                order = (frozen, standalone) if i % 2 == 0 else (standalone, frozen)
                values = {source: measure(graphs[source, variant]) for source, variant in order}
                samples.append(dict(order=[source for source, _ in order], time_us=values,
                                    ratio=values['standalone'] / values['golden']))
            ratios = [item['ratio'] for item in samples]
            rng = Random(410)
            resampled = sorted(median(rng.choices(ratios, k=pairs)) for _ in range(4000))
            by_mode[mode] = dict(paired_median_ratio=median(ratios),
                                 paired_ratio_95pct=[resampled[100], resampled[3899]],
                                 median_us={source: median(item['time_us'][source] for item in samples)
                                            for source in ('golden', 'standalone')}, pairs=samples)
        return dict(launches_per_graph=launches, graphs_per_timing=replays, modes=by_mode)


def qualify(driver, standalone, golden, *, pairs, exact):
    reports = []
    for (batch, k), cases in sorted(standalone.items()):
        variants = {'standalone': cases}
        if golden:
            variants = dict(golden=golden[batch, k], **variants)
        bounds, = {case['bounds'] for rows in variants.values() for case in rows.values()}
        records = []
        with ExitStack() as stack:
            loaded = {(source, mode): Image(driver, variants[source][mode], stack, exact=exact)
                      for source, candidates in variants.items() for mode in candidates}
            patterns = ('signed', 'tile-signature') if exact else ('random', 'signed', 'tile-signature', 'zero')
            for pattern in patterns:
                a, b, reference = fixture(batch, k, bounds, pattern)
                if pattern == 'random':
                    timing_inputs = a, b
                expected_bits = None
                for offsets in OFFSETS[:1] if exact else OFFSETS:
                    for (source, mode), image in loaded.items():
                        # New allocations leave output uninitialized for initcheck.
                        with ExitStack() as allocations:
                            buffers = Buffers(driver, allocations, (a, b), len(reference), offsets, exact=exact)
                            if not exact:
                                buffers.reset()
                            driver.synchronize_uploads()
                            image.launch(buffers.params)
                            driver.synchronize()
                            bits = buffers.read()
                        if expected_bits is None:
                            worst = compare_output(bits, reference, pattern)
                            expected_bits = bits
                        if bits != expected_bits:
                            index = next(i for i, (a, b) in enumerate(zip(bits, expected_bits)) if a != b) // 4
                            observed, expected = (struct.unpack_from('<f', payload, 4 * index)[0]
                                                  for payload in (bits, expected_bits))
                            raise ValueError(f'GEMM bitwise mismatch {batch=} {k=} {pattern} {offsets=} '
                                             f'{source}/{mode}, first index {index}, {observed=} {expected=} '
                                             f'host={reference[index]}, got bits={bits[4*index:4*index+4].hex()}, '
                                             f'expected bits={expected_bits[4*index:4*index+4].hex()}')
                    records.append(dict(pattern=pattern, offsets=offsets, output_sha256=sha(expected_bits),
                                        max_abs_error=worst))
            measurements = None
            if pairs:
                buffers = Buffers(driver, stack, timing_inputs, len(reference), OFFSETS[0], exact=True)
                driver.synchronize_uploads()
                measurements = timing(driver, loaded, buffers, pairs)
            reports.append(dict(batch=batch, k=k, bounds=bounds, checks=records,
                                resources={f'{source}/{mode}': image.resources
                                           for (source, mode), image in loaded.items()},
                                cubins={f'{source}/{mode}': variants[source][mode]['row']['image']['cubin_sha256']
                                        for source, mode in loaded},
                                timing=measurements))
    return reports


def shape_arg(value):
    try:
        batch, k = map(int, value.split(','))
    except ValueError as error:
        raise argparse.ArgumentTypeError('expected B,K') from error
    return batch, k


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--golden', type=Path, help='compare all modes against a frozen manifest')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--shape', type=shape_arg, action='append', default=[])
    parser.add_argument('--mode', choices=MODES, action='append',
                        help='qualify a subset of the three GEMM modes')
    parser.add_argument('--pairs', type=int, default=0)
    parser.add_argument('--exact', action='store_true', help='use exact uninitialized output for sanitizer')
    args = parser.parse_args()
    require(args.pairs == 0 or (args.pairs >= 4 and args.golden and not args.exact),
            'paired timing needs at least four pairs and a golden manifest')
    require(not args.output.exists(), 'qualification output must be new')
    require(sys.flags.isolated and sys.flags.no_site, 'use /usr/bin/python3 -I -S')
    dependencies = {name: importlib.util.find_spec(name) is not None for name in FRAMEWORKS}
    require(not any(dependencies.values()), 'framework packages must be unavailable in this process')
    uuid = os.environ.get('CUDA_VISIBLE_DEVICES', '')
    require(uuid.startswith('GPU-') and ',' not in uuid, 'set the exclusive H100 UUID in CUDA_VISIBLE_DEVICES')
    modes = tuple(dict.fromkeys(args.mode or MODES))
    standalone, standalone_sha = load_manifest(args.manifest, set(args.shape), modes)
    golden, golden_sha = (load_manifest(args.golden, set(standalone), modes)
                          if args.golden else (None, None))
    before = gpu_state(uuid)
    with ExitStack() as stack:
        driver = Driver(uuid, stack)
        reports = qualify(driver, standalone, golden, pairs=args.pairs, exact=args.exact)
        inside = gpu_state(uuid)
    after = gpu_state(uuid)
    count = sum(len(report['checks']) for report in reports)
    variants = len(modes) * (2 if golden else 1)
    with args.output.open('x') as out:
        json.dump(dict(status='passed', comparison='bitwise and independent host reference',
                       manifest_sha256=standalone_sha, golden_sha256=golden_sha, framework_installed=dependencies,
                       device_before=before, device_active=inside, device_after=after,
                       python=sys.version, exact_allocations=args.exact, bitwise_groups=count,
                       variants_per_group=variants, correctness_launches=count * variants,
                       shapes=reports), out, indent=2, allow_nan=False)
        out.write('\n')
    print(f'passed {count} bitwise groups, {variants} variants per group', flush=True)


if __name__ == '__main__':
    main()
