import re,numpy as np,os
import qualify_gemm_standalone as cu
UUID=os.environ['CUDA_VISIBLE_DEVICES']
def shape(c):return list(map(int,re.fullmatch(r'.+_m(\d+)n(\d+)k(\d+)',c).groups()))
def fixtures(c,b,trial):
    rng=np.random.default_rng(7823+trial)
    for name in ['integer','sparse','random']:
        m,n,k=shape(c); shapes=[(b,m,k),(b,k,n)]
        if name=='integer':a,y=[rng.integers(-3,4,sh).astype('f2') for sh in shapes]
        elif name=='sparse':a,y=[np.where(rng.random(sh)<.13,rng.integers(-5,6,sh)/8,0).astype('f2') for sh in shapes]
        else:a,y=[rng.uniform(-1,1,sh).astype('f2') for sh in shapes]
        ref=a.astype('f8')@y.astype('f8');rr=ref.sum(axis=2 if c.startswith("row") else 1)
        def check(raw):
            errors=[]
            for i,expected in enumerate([ref,rr][:len(raw)]):
                v=np.frombuffer(raw[i],'<f4').reshape(expected.shape);err=float(np.max(np.abs(expected-v)))
                bound=0 if name!='random' else [.0005,.006][i]
                if not np.isfinite(v).all() or err>bound:raise ValueError((c,b,name,i,err,bound))
                errors.append(err)
            return errors
        yield name,[a.tobytes(),y.tobytes()],[ref.size*4]+([rr.size*4] if not c.startswith('matrix') else []),check
