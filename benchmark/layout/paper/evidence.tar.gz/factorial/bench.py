import sys,ctypes as ct,json,random,hashlib
from pathlib import Path
from contextlib import ExitStack
import numpy as np
from fixtures import cu,UUID,fixtures,shape
root=Path.cwd()
reg=json.loads(Path('registration.json').read_text())
class Image:
 def __init__(self,d,st,p,grid,info):
  self.d=d;self.grid=grid;self.smem=info['smem']
  module=d.value('cuModuleLoadData',cu.P,ct.c_char_p((p/'kernel.cubin').read_bytes()));st.callback(d.call,'cuModuleUnload',module)
  self.fn=d.value('cuModuleGetFunction',cu.P,module,info['symbol'].encode())
  if self.smem:d.call('cuFuncSetAttribute',self.fn,8,self.smem)
 def launch(self,params):
  self.d.call('cuLaunchKernel',self.fn,self.grid,1,1,256,1,1,self.smem,self.d.stream,params,None)
def params(ptr):
 a=[cu.D(v+256) for v in ptr];a.extend([cu.D(0) for _ in range(5-len(a))])
 return a,(cu.P*len(a))(*(ct.cast(ct.byref(v),cu.P) for v in a))
def run(c,group,profile=False):
 folder=root/'images'/c
 arms=json.loads((folder/(group+'.json')).read_text())
 res=dict(checks={},samples={},excluded={})
 with ExitStack() as st:
  d=cu.Driver(UUID,st);allowed={}
  for arm in arms:
   p=folder/arm;info=json.loads((p/'info.json').read_text())
   if info['smem']>232448:
    res['excluded'][arm]=f"{info['smem']} dynamic shared bytes > 232448";continue
   allowed[arm]=Image(d,st,p,2,info)
  if not profile:
   # Exact Frisk equivalence and independent references on all three backends.
   for name,ins,outs,verify in fixtures(c,2,1):
    with ExitStack() as sub:
     guard=b'\xa7'*256;va=[d.allocate(sub,len(v)+512) for v in ins];vv=[d.allocate(sub,n+512) for n in outs]
     for p,v in zip(va,ins): d.copy_to(p,guard+v+guard)
     a,par=params(va+vv);frisk=set(); exact_c=set(); exact_r=set()
     for arm,im in allowed.items():
      for p,n in zip(vv,outs):d.copy_to(p,guard+b'\xff'*n+guard)
      d.synchronize_uploads();im.launch(par);d.synchronize();raw=[]
      for p,n in zip(vv,outs):
       v=d.copy_from(p,n+512);assert v[:256]==guard==v[-256:],(c,arm);raw.append(v[256:-256])
      if arm.startswith('C') and c.startswith('fan'):
       assert raw[1]==b'\xff'*len(raw[1]); raw=raw[:1]
      if arm in ['C12','C21','R12','R21','fix','xp-d']:
       exact_c.add(hashlib.sha256(raw[0]).hexdigest())
       if len(raw)>1:exact_r.add(hashlib.sha256(raw[1]).hexdigest())
      res['checks'][name+'-'+arm]=verify(raw)
      if arm.startswith(('w','F')):frisk.add(tuple(hashlib.sha256(b).hexdigest() for b in raw))
     assert max(len(frisk),len(exact_c),len(exact_r))<=1
     for p,v in zip(va,ins):assert d.copy_from(p,len(v)+512)==guard+v+guard
  for grid in ([132] if profile else reg['grids']):
   with ExitStack() as sub:
    m,n,k=shape(c);rng=np.random.default_rng(7881);ptr=[]
    for cnt in [m*k,k*n]:
     v=rng.uniform(-1,1,(grid,cnt)).astype('f2').tobytes();p=d.allocate(sub,len(v)+512);ptr.append(p);d.copy_to(p,b'\0'*256+v+b'\0'*256)
    for cnt in [m*n]+([n] if c.startswith('fan') else [m] if c.startswith('row') else []):ptr.append(d.allocate(sub,grid*cnt*4+512))
    a,par=params(ptr);d.synchronize_uploads()
    for im in allowed.values():im.grid=grid
    if profile:
     for key,im in allowed.items():print('PROFILE',c,key,flush=True);im.launch(par);d.synchronize()
     continue
    graphs={key:sub.enter_context(cu.capture(d,im,par,8)) for key,im in allowed.items()}
    ev=[d.value('cuEventCreate',cu.P,0) for _ in range(2)]
    for e in ev:sub.callback(d.call,'cuEventDestroy_v2',e)
    for _ in range(8):
     for gr in graphs.values():d.call('cuGraphLaunch',gr,d.stream)
    d.synchronize();rnd=random.Random(int(__import__("os").environ.get("PAIR_SEED",4728))+grid);rows=[]
    for _ in range(reg['rounds']):
     order=list(graphs);rnd.shuffle(order);row={}
     for key in order:
      d.call('cuEventRecord',ev[0],d.stream);d.call('cuGraphLaunch',graphs[key],d.stream);d.call('cuEventRecord',ev[1],d.stream);d.call('cuEventSynchronize',ev[1]);v=ct.c_float();d.call('cuEventElapsedTime',ct.byref(v),*ev);row[key]=v.value*1000/8
     rows.append(row)
    res['samples'][grid]=rows
 if not profile:
  out=root/'results'/group;out.mkdir(exist_ok=True,parents=True);(out/(c+'.json')).write_text(json.dumps(res))
if __name__=='__main__':
 group=sys.argv[1]
 for c in sys.argv[2:]:
  print(group,c,flush=True);run(c,group,group.startswith('ncu'))
